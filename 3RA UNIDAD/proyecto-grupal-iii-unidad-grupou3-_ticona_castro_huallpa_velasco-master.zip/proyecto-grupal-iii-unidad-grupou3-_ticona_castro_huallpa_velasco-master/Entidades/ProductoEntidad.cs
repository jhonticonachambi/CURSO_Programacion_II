﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ProductoEntidad
    {
        public int id_producto { get; set; }
        public int id_categoria { get; set; }
        public string nombre_producto { get; set; }
        public string descripcion { get; set; }
        public string precio { get; set; }
        public string estado { get; set; }
    }
}
