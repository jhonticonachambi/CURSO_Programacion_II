﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PedidoEntidad
    {
        //VENTAS 2
        public int id_pedido { get; set; }
        public int id_categoria { get; set; }

        public int id_producto { get; set; }
        public int id_mesa { get; set; }
        public string cliente { get; set; }
        public string nro_documento { get; set; }
        public string telefono { get; set; }
        public string direccion { get; set; }
        public int cantidad { get; set; }
        public string estado { get; set; }
        public string fecha { get; set; }








    }
}
