﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class VentaEntidad
    {
        public int id_pedido { get; set; }
        public string categoria { get; set; }
        public string producto { get; set; }
        public string mesa { get; set; }
        public string cliente { get; set; }
        public string nro_documento { get; set; }
        public string telefono { get; set; }
        public string direccion { get; set; }
        public string preciounitario { get; set; }
        public int cantidad { get; set; }
        public string estado { get; set; }
        public string fecha { get; set; }
        public string subtotal { get; set; }
        public string igv { get; set; }
        public string total { get; set; }
    }
}
