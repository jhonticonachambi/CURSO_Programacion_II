﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class MesaEntidad
    {
        public int id_mesa { get; set; }
        public int numero { get; set; }
        public string estado { get; set; }
    }
}
