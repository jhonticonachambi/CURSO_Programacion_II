﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace Presentacion
{
    public partial class Principal : Form
    {
        public string nombre;
        public string apellido;
        public string cargo;
        public Principal()
        {
            InitializeComponent();
        }

        private void panelChildForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Principal_Load(object sender, EventArgs e)
        {
            hideSubMenu();
            lblApellido.Text = apellido;
            lblNombre.Text = nombre;
            lblCargo.Text = cargo;
            //lblFecha.Text = DateTime.Now.ToString();
            //lblFechaGrande.Text = DateTime.Now.ToString();


            if (this.cargo.Equals("Administrador"))
            {
                btnMedia.Visible = true;
                btnPlaylist.Visible = true;
                btnCaja.Visible = true;
                btnCocina.Visible = true;
                btnAdministrar.Visible = true;
            }
            else
            {
                if (this.cargo.Equals("Supervisor"))
                {
                    btnMedia.Visible = false;
                    btnPlaylist.Visible = true;
                    btnCaja.Visible = true;
                    btnCocina.Visible = true;
                    btnAdministrar.Visible = true;
                }
                else
                {
                    if (this.cargo.Equals("Mozo"))
                    {
                        btnMedia.Visible = false;
                        btnPlaylist.Visible = false;
                        btnCaja.Visible = true;
                        btnCocina.Visible = true;
                        btnAdministrar.Visible = false;
                    }
                    else
                    {
                        if (this.cargo.Equals("Cajero"))
                        {
                            btnMedia.Visible = false;
                            btnPlaylist.Visible = false;
                            btnCaja.Visible = true;
                            btnCocina.Visible = false;
                            btnAdministrar.Visible = false;
                        }
                        else
                        {
                            btnMedia.Visible = false;
                            btnPlaylist.Visible = false;
                            btnCaja.Visible = false;
                            btnCocina.Visible = false;
                            btnAdministrar.Visible = false;

                        }
                    }
                }
            }


        }
        private void hideSubMenu()
        {
            panelSubMenuMedia.Visible = false;
            panelPlayListSubMenu.Visible = false;
            PanelCaja.Visible = false;
            panelCocina.Visible = false;
            panelAdmin.Visible = false;
            //panelEcualizadorSubmenu.Visible = false;
        }
        private void showSubMenu(Panel SubMenu)
        {
            if (SubMenu.Visible == false)
            {
                hideSubMenu();
                SubMenu.Visible = true;
            }
            else
            {
                SubMenu.Visible = false;
            }
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubMenuMedia);
        }





        private void btnPlaylist_Click(object sender, EventArgs e)
        {
            showSubMenu(panelPlayListSubMenu);
        }

        private void btnEcualizador_Click(object sender, EventArgs e)
        {
            //showSubMenu(panelEcualizadorSubmenu);
        }

        private Form activeForm = null;

        private void openchildFormInPanel(Form chilForm)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = chilForm;
            chilForm.TopLevel = false;
            chilForm.FormBorderStyle = FormBorderStyle.None;
            chilForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(chilForm);
            panelChildForm.Tag = chilForm;
            chilForm.BringToFront();
            chilForm.Show();

        }

        private void btnCaja_Click(object sender, EventArgs e)
        {
            showSubMenu(PanelCaja);
        }

        private void btnCocina_Click(object sender, EventArgs e)
        {
            showSubMenu(panelCocina);
        }

        private void btnAdministrar_Click(object sender, EventArgs e)
        {
            showSubMenu(panelAdmin);
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmTipoUsuario());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmPedidoVentas());
        }

        private void btnProducto_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmProducto());
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmReportes());
        }

        private void btnMesas_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmMesa());
        }

        private void btnManUsuario_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmUsuario());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmMantenimiento());
        }

        private void btnEjemplo_Click(object sender, EventArgs e)
        {
            //openchildFormInPanel(new FrmEjemplo2());
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblFecha.Text = DateTime.Now.ToString();
            lblFechaGrande.Text = DateTime.Now.ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            openchildFormInPanel(new FrmMenuDelDia());
        }

        private void btnModUsuario_Click(object sender, EventArgs e)
        {
            
        }
    }
}
