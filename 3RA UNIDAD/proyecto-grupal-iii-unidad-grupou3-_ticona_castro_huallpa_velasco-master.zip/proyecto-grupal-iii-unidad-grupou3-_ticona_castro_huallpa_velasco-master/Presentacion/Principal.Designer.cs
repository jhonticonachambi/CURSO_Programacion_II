﻿namespace Presentacion
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelSubMenuMedia = new System.Windows.Forms.Panel();
            this.btnManUsuario = new System.Windows.Forms.Button();
            this.btnUsuario = new System.Windows.Forms.Button();
            this.panelPlayListSubMenu = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.btnProducto = new System.Windows.Forms.Button();
            this.PanelMenu = new System.Windows.Forms.Panel();
            this.panelAdmin = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.btnAdministrar = new System.Windows.Forms.Button();
            this.panelCocina = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.btnCocina = new System.Windows.Forms.Button();
            this.PanelCaja = new System.Windows.Forms.Panel();
            this.btnMesas = new System.Windows.Forms.Button();
            this.btnCaja = new System.Windows.Forms.Button();
            this.btnPlaylist = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.lblFechaGrande = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblApellido = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelSubMenuMedia.SuspendLayout();
            this.panelPlayListSubMenu.SuspendLayout();
            this.PanelMenu.SuspendLayout();
            this.panelAdmin.SuspendLayout();
            this.panelCocina.SuspendLayout();
            this.PanelCaja.SuspendLayout();
            this.panelChildForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(200, 90);
            this.panelLogo.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-8, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(209, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelSubMenuMedia
            // 
            this.panelSubMenuMedia.Controls.Add(this.btnManUsuario);
            this.panelSubMenuMedia.Controls.Add(this.btnUsuario);
            this.panelSubMenuMedia.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubMenuMedia.Location = new System.Drawing.Point(0, 135);
            this.panelSubMenuMedia.Name = "panelSubMenuMedia";
            this.panelSubMenuMedia.Size = new System.Drawing.Size(200, 101);
            this.panelSubMenuMedia.TabIndex = 3;
            // 
            // btnManUsuario
            // 
            this.btnManUsuario.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnManUsuario.FlatAppearance.BorderSize = 0;
            this.btnManUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManUsuario.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnManUsuario.Location = new System.Drawing.Point(0, 45);
            this.btnManUsuario.Name = "btnManUsuario";
            this.btnManUsuario.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btnManUsuario.Size = new System.Drawing.Size(200, 45);
            this.btnManUsuario.TabIndex = 1;
            this.btnManUsuario.Text = "Mantenimiento Usuario";
            this.btnManUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManUsuario.UseVisualStyleBackColor = true;
            this.btnManUsuario.Click += new System.EventHandler(this.btnManUsuario_Click);
            // 
            // btnUsuario
            // 
            this.btnUsuario.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnUsuario.FlatAppearance.BorderSize = 0;
            this.btnUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsuario.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnUsuario.Location = new System.Drawing.Point(0, 0);
            this.btnUsuario.Name = "btnUsuario";
            this.btnUsuario.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btnUsuario.Size = new System.Drawing.Size(200, 45);
            this.btnUsuario.TabIndex = 0;
            this.btnUsuario.Text = "Mantenimiento Cargo";
            this.btnUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUsuario.UseVisualStyleBackColor = true;
            this.btnUsuario.Click += new System.EventHandler(this.btnUsuario_Click);
            // 
            // panelPlayListSubMenu
            // 
            this.panelPlayListSubMenu.Controls.Add(this.button2);
            this.panelPlayListSubMenu.Controls.Add(this.btnProducto);
            this.panelPlayListSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPlayListSubMenu.Location = new System.Drawing.Point(0, 281);
            this.panelPlayListSubMenu.Name = "panelPlayListSubMenu";
            this.panelPlayListSubMenu.Size = new System.Drawing.Size(200, 104);
            this.panelPlayListSubMenu.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.Gainsboro;
            this.button2.Location = new System.Drawing.Point(0, 45);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(200, 45);
            this.button2.TabIndex = 1;
            this.button2.Text = "Mantenimiento Producto";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnProducto
            // 
            this.btnProducto.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProducto.FlatAppearance.BorderSize = 0;
            this.btnProducto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProducto.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnProducto.Location = new System.Drawing.Point(0, 0);
            this.btnProducto.Name = "btnProducto";
            this.btnProducto.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btnProducto.Size = new System.Drawing.Size(200, 45);
            this.btnProducto.TabIndex = 0;
            this.btnProducto.Text = "Mantenimiento Categoria";
            this.btnProducto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProducto.UseVisualStyleBackColor = true;
            this.btnProducto.Click += new System.EventHandler(this.btnProducto_Click);
            // 
            // PanelMenu
            // 
            this.PanelMenu.AutoScroll = true;
            this.PanelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.PanelMenu.Controls.Add(this.panelAdmin);
            this.PanelMenu.Controls.Add(this.btnAdministrar);
            this.PanelMenu.Controls.Add(this.panelCocina);
            this.PanelMenu.Controls.Add(this.btnCocina);
            this.PanelMenu.Controls.Add(this.PanelCaja);
            this.PanelMenu.Controls.Add(this.btnCaja);
            this.PanelMenu.Controls.Add(this.panelPlayListSubMenu);
            this.PanelMenu.Controls.Add(this.btnPlaylist);
            this.PanelMenu.Controls.Add(this.panelSubMenuMedia);
            this.PanelMenu.Controls.Add(this.btnMedia);
            this.PanelMenu.Controls.Add(this.panelLogo);
            this.PanelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelMenu.Location = new System.Drawing.Point(0, 0);
            this.PanelMenu.Name = "PanelMenu";
            this.PanelMenu.Size = new System.Drawing.Size(217, 734);
            this.PanelMenu.TabIndex = 2;
            // 
            // panelAdmin
            // 
            this.panelAdmin.Controls.Add(this.button7);
            this.panelAdmin.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAdmin.Location = new System.Drawing.Point(0, 640);
            this.panelAdmin.Name = "panelAdmin";
            this.panelAdmin.Size = new System.Drawing.Size(200, 124);
            this.panelAdmin.TabIndex = 11;
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.Gainsboro;
            this.button7.Location = new System.Drawing.Point(0, 0);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button7.Size = new System.Drawing.Size(200, 45);
            this.button7.TabIndex = 0;
            this.button7.Text = "Menu";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnAdministrar
            // 
            this.btnAdministrar.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAdministrar.FlatAppearance.BorderSize = 0;
            this.btnAdministrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdministrar.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnAdministrar.Image = global::Presentacion.Properties.Resources.settings;
            this.btnAdministrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdministrar.Location = new System.Drawing.Point(0, 595);
            this.btnAdministrar.Name = "btnAdministrar";
            this.btnAdministrar.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnAdministrar.Size = new System.Drawing.Size(200, 45);
            this.btnAdministrar.TabIndex = 10;
            this.btnAdministrar.Text = "Administrar";
            this.btnAdministrar.UseVisualStyleBackColor = true;
            this.btnAdministrar.Click += new System.EventHandler(this.btnAdministrar_Click);
            // 
            // panelCocina
            // 
            this.panelCocina.Controls.Add(this.button5);
            this.panelCocina.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCocina.Location = new System.Drawing.Point(0, 533);
            this.panelCocina.Name = "panelCocina";
            this.panelCocina.Size = new System.Drawing.Size(200, 62);
            this.panelCocina.TabIndex = 9;
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.Gainsboro;
            this.button5.Location = new System.Drawing.Point(0, 0);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(200, 45);
            this.button5.TabIndex = 0;
            this.button5.Text = "Pedidos";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnCocina
            // 
            this.btnCocina.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCocina.FlatAppearance.BorderSize = 0;
            this.btnCocina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCocina.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCocina.Image = global::Presentacion.Properties.Resources.copy;
            this.btnCocina.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCocina.Location = new System.Drawing.Point(0, 488);
            this.btnCocina.Name = "btnCocina";
            this.btnCocina.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnCocina.Size = new System.Drawing.Size(200, 45);
            this.btnCocina.TabIndex = 8;
            this.btnCocina.Text = "Cocina";
            this.btnCocina.UseVisualStyleBackColor = true;
            this.btnCocina.Click += new System.EventHandler(this.btnCocina_Click);
            // 
            // PanelCaja
            // 
            this.PanelCaja.Controls.Add(this.btnMesas);
            this.PanelCaja.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelCaja.Location = new System.Drawing.Point(0, 430);
            this.PanelCaja.Name = "PanelCaja";
            this.PanelCaja.Size = new System.Drawing.Size(200, 58);
            this.PanelCaja.TabIndex = 7;
            // 
            // btnMesas
            // 
            this.btnMesas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMesas.FlatAppearance.BorderSize = 0;
            this.btnMesas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMesas.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMesas.Location = new System.Drawing.Point(0, 0);
            this.btnMesas.Name = "btnMesas";
            this.btnMesas.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btnMesas.Size = new System.Drawing.Size(200, 48);
            this.btnMesas.TabIndex = 1;
            this.btnMesas.Text = "Mesas";
            this.btnMesas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMesas.UseVisualStyleBackColor = true;
            this.btnMesas.Click += new System.EventHandler(this.btnMesas_Click);
            // 
            // btnCaja
            // 
            this.btnCaja.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCaja.FlatAppearance.BorderSize = 0;
            this.btnCaja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaja.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCaja.Image = global::Presentacion.Properties.Resources.credit_card;
            this.btnCaja.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCaja.Location = new System.Drawing.Point(0, 385);
            this.btnCaja.Name = "btnCaja";
            this.btnCaja.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnCaja.Size = new System.Drawing.Size(200, 45);
            this.btnCaja.TabIndex = 6;
            this.btnCaja.Text = "Caja";
            this.btnCaja.UseVisualStyleBackColor = true;
            this.btnCaja.Click += new System.EventHandler(this.btnCaja_Click);
            // 
            // btnPlaylist
            // 
            this.btnPlaylist.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPlaylist.FlatAppearance.BorderSize = 0;
            this.btnPlaylist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlaylist.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnPlaylist.Image = global::Presentacion.Properties.Resources.inventory;
            this.btnPlaylist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPlaylist.Location = new System.Drawing.Point(0, 236);
            this.btnPlaylist.Name = "btnPlaylist";
            this.btnPlaylist.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnPlaylist.Size = new System.Drawing.Size(200, 45);
            this.btnPlaylist.TabIndex = 4;
            this.btnPlaylist.Text = "Inventario";
            this.btnPlaylist.UseVisualStyleBackColor = true;
            this.btnPlaylist.Click += new System.EventHandler(this.btnPlaylist_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMedia.FlatAppearance.BorderSize = 0;
            this.btnMedia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedia.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMedia.Image = global::Presentacion.Properties.Resources.user;
            this.btnMedia.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMedia.Location = new System.Drawing.Point(0, 90);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnMedia.Size = new System.Drawing.Size(200, 45);
            this.btnMedia.TabIndex = 2;
            this.btnMedia.Text = "Usuario";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // panelChildForm
            // 
            this.panelChildForm.Controls.Add(this.lblFechaGrande);
            this.panelChildForm.Controls.Add(this.pictureBox2);
            this.panelChildForm.Location = new System.Drawing.Point(217, 32);
            this.panelChildForm.Name = "panelChildForm";
            this.panelChildForm.Size = new System.Drawing.Size(1000, 700);
            this.panelChildForm.TabIndex = 3;
            this.panelChildForm.Paint += new System.Windows.Forms.PaintEventHandler(this.panelChildForm_Paint);
            // 
            // lblFechaGrande
            // 
            this.lblFechaGrande.AutoSize = true;
            this.lblFechaGrande.Font = new System.Drawing.Font("Arial Narrow", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaGrande.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblFechaGrande.Location = new System.Drawing.Point(139, 381);
            this.lblFechaGrande.Name = "lblFechaGrande";
            this.lblFechaGrande.Size = new System.Drawing.Size(0, 75);
            this.lblFechaGrande.TabIndex = 9;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(80, 81);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(624, 178);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panel1.Controls.Add(this.lblNombre);
            this.panel1.Controls.Add(this.lblFecha);
            this.panel1.Controls.Add(this.lblApellido);
            this.panel1.Controls.Add(this.lblCargo);
            this.panel1.Location = new System.Drawing.Point(217, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 31);
            this.panel1.TabIndex = 10;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblNombre.Location = new System.Drawing.Point(15, 9);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(58, 17);
            this.lblNombre.TabIndex = 4;
            this.lblNombre.Text = "Nombre";
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblFecha.Location = new System.Drawing.Point(632, 9);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(47, 17);
            this.lblFecha.TabIndex = 8;
            this.lblFecha.Text = "Fecha";
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellido.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblApellido.Location = new System.Drawing.Point(164, 9);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(58, 17);
            this.lblApellido.TabIndex = 5;
            this.lblApellido.Text = "Apellido";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblCargo.Location = new System.Drawing.Point(350, 9);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(46, 17);
            this.lblCargo.TabIndex = 6;
            this.lblCargo.Text = "Cargo";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 734);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelChildForm);
            this.Controls.Add(this.PanelMenu);
            this.Name = "Principal";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelSubMenuMedia.ResumeLayout(false);
            this.panelPlayListSubMenu.ResumeLayout(false);
            this.PanelMenu.ResumeLayout(false);
            this.panelAdmin.ResumeLayout(false);
            this.panelCocina.ResumeLayout(false);
            this.PanelCaja.ResumeLayout(false);
            this.panelChildForm.ResumeLayout(false);
            this.panelChildForm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelSubMenuMedia;
        private System.Windows.Forms.Button btnPlaylist;
        private System.Windows.Forms.Panel panelPlayListSubMenu;
        private System.Windows.Forms.Button btnProducto;
        private System.Windows.Forms.Panel PanelMenu;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.Button btnUsuario;
        private System.Windows.Forms.Panel panelAdmin;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnAdministrar;
        private System.Windows.Forms.Panel panelCocina;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnCocina;
        private System.Windows.Forms.Panel PanelCaja;
        private System.Windows.Forms.Button btnCaja;
        private System.Windows.Forms.Button btnMesas;
        private System.Windows.Forms.Button btnManUsuario;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Label lblFechaGrande;
        private System.Windows.Forms.Timer timer1;
    }
}