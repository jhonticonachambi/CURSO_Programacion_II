﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

using System.Data.SqlClient;
using System.Web.UI.WebControls;


namespace Presentacion
{
    public partial class FrmUsuario : Form
    {
        public FrmUsuario()
        {
            InitializeComponent();
        }
        /* METODOS*/

        private void Cargarcomboestado()
        {
            cmbEstado.Items.Clear();
            cmbEstado.Items.Add(new ListItem("Activo", "A"));
            cmbEstado.Items.Add(new ListItem("Inactivo", "I"));
        }
        private void Cargarcombosexo()
        {
            cmbSexo.Items.Clear();
            cmbSexo.Items.Add(new ListItem("Masculino", "M"));
            cmbSexo.Items.Add(new ListItem("Femenino", "F"));
        }
        private void TitulosGrilla()
        {
            dgvUsuario.Columns[0].Visible = false; //Columna Seleccionar
            dgvUsuario.Columns[0].Visible = false; //Columna Seleccionar
            dgvUsuario.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[10].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[11].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[12].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[1].HeaderText = "Código";
            dgvUsuario.Columns[2].HeaderText = "Cargo";
            dgvUsuario.Columns[3].HeaderText = "Documento";
            dgvUsuario.Columns[4].HeaderText = "Nro. Documento";
            dgvUsuario.Columns[5].HeaderText = "Nombres";
            dgvUsuario.Columns[6].HeaderText = "Apellidos";
            dgvUsuario.Columns[7].HeaderText = "Contraseña";
            dgvUsuario.Columns[8].HeaderText = "Email";
            dgvUsuario.Columns[9].HeaderText = "Celular";
            dgvUsuario.Columns[10].HeaderText = "Direccion";
            dgvUsuario.Columns[11].HeaderText = "Sexo";
            dgvUsuario.Columns[12].HeaderText = "Estado";
        }
        private void Listar()
        {
            try
            {
                dgvUsuario.DataSource = UsuarioNegocio.Listar();
                this.TitulosGrilla();
                lblCantidad.Text = "Total de registro: " + Convert.ToString(dgvUsuario.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }
        private void Visualizar()
        {
            btnEliminar.Visible = false;
            btnModificar.Visible = false;
            btnCancelar.Visible = false;
            btnActivar.Visible = false;
            btnDesactivar.Visible = false;
            dgvUsuario.Columns[0].Visible = false;
        }
        private void ListarCombo()
        {
            try
            {
                cmbCargo.DataSource = UsuarioNegocio.Combo();
                cmbCargo.DisplayMember = "descripcion";
                cmbCargo.ValueMember = "id_tipo_usuario";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void Limpiar()
        {
            txtApellidoUsu.Clear();
            txtCelularUsu.Clear();
            txtcodigo.Clear();
            txtContraseña.Clear();
            txtDireccionUsu.Clear();
            txtEmailUsu.Clear();
            txtNombreUsu.Clear();
            txtnro.Clear();
            txttipo.Clear();
            cmbCargo.Text = "";
            cmbEstado.Text = "";
            cmbSexo.Text = "";
        }

        private void FrmUsuario_Load(object sender, EventArgs e)
        {
            this.ListarCombo();
            this.Cargarcomboestado();
            this.Cargarcombosexo();
            this.Visualizar();
            this.Listar();
            txtcodigo.Enabled = false;
            //cmbCargo2.Visible = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";
                if (txtnro.Text == string.Empty)
                {
                    MessageBox.Show("Por favor rellene el campo...");
                }
                else
                {
                    rpta = UsuarioNegocio.Insertar(Convert.ToInt32(cmbCargo.SelectedValue), txttipo.Text.Trim(), txtnro.Text.Trim(), txtNombreUsu.Text, txtApellidoUsu.Text, txtContraseña.Text.Trim(), txtEmailUsu.Text.Trim(), txtCelularUsu.Text.Trim(), txtDireccionUsu.Text, cmbSexo.Text.Trim(), cmbEstado.Text.Trim());
                    if (rpta.Equals("OK"))
                    {
                        MessageBox.Show("Guardado correctamente");
                        this.Limpiar();
                        this.Visualizar();
                        this.Listar();
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";

                if (txtnro.Text == string.Empty)
                {
                    MessageBox.Show("Por favor complete el campo");
                }
                else
                {
                    rpta = UsuarioNegocio.Actualizar(Convert.ToInt32(txtcodigo.Text.Trim()), Convert.ToInt32(cmbCargo.SelectedValue), txttipo.Text.Trim(), txtnro.Text.Trim(), txtNombreUsu.Text, txtApellidoUsu.Text, txtContraseña.Text.Trim(), txtEmailUsu.Text.Trim(), txtCelularUsu.Text.Trim(), txtDireccionUsu.Text, cmbSexo.Text.Trim(), cmbEstado.Text.Trim());

                    if (rpta.Equals("OK"))
                    {
                        MessageBox.Show("Actualizado correctamente");
                        this.Limpiar();
                        this.Listar();
                        btnGuardar.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de eliminar el(los) registro(s)", "Sistema Restaurante", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta = "";

                    foreach (DataGridViewRow row in dgvUsuario.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = UsuarioNegocio.Eliminar(codigo);

                            if (rpta == "OK")
                            {
                                MessageBox.Show("Se elimino el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                btnEliminar.Visible = false;
                                btnGuardar.Visible = true;
                                chkSeleccionar.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            Limpiar();
            btnEliminar.Visible = false;
            btnCancelar.Visible = false;
            btnGuardar.Visible = true;
            btnModificar.Visible = false;
            chkSeleccionar.Checked = false;
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de activar el(los) registro(s)", "Sistema Escritorio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta = "";

                    foreach (DataGridViewRow row in dgvUsuario.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = UsuarioNegocio.Activar(codigo);

                            if (rpta == "OK")
                            {
                                MessageBox.Show("Se activo el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                chkSeleccionar.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de desactivar el(los) registro(s)", "Sistema Escritorio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta = "";

                    foreach (DataGridViewRow row in dgvUsuario.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = UsuarioNegocio.Desactivar(codigo);

                            if (rpta == "OK")
                            {
                                MessageBox.Show("Se desactivo el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                chkSeleccionar.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void Buscar()
        {
            try
            {
                string buscar;
                buscar = txtBuscar.Text;
                dgvUsuario.DataSource = UsuarioNegocio.Buscar(buscar);
                this.TitulosGrilla();
                lblCantidad.Text = "Total de registro: " + Convert.ToString(dgvUsuario.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }

        private void metroCheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                dgvUsuario.Columns[0].Visible = true;
                btnGuardar.Visible = false;
                btnModificar.Visible = false;
                btnEliminar.Visible = true;
                btnCancelar.Visible = true;
                btnActivar.Visible = true;
                btnDesactivar.Visible = true;
                Limpiar();
            }
            else
            {
                dgvUsuario.Columns[0].Visible = false;
                btnGuardar.Visible = true;
                btnEliminar.Visible = false;
                btnCancelar.Visible = false;
                btnActivar.Visible = false;
                btnDesactivar.Visible = false;
            }
        }

        private void dgvUsuario_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                btnModificar.Visible = true;
                btnCancelar.Visible = true;
                btnGuardar.Visible = false;
                txtcodigo.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["id_usuario"].Value);
                cmbCargo.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["descripcion"].Value);
                txttipo.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["tipo_identificacion"].Value);
                txtnro.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["nro_identificacion"].Value);
                txtNombreUsu.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["nombres"].Value);
                txtApellidoUsu.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["apellidos"].Value);
                txtContraseña.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["contraseña"].Value);
                txtEmailUsu.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["email"].Value);
                txtCelularUsu.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["celular"].Value);
                txtDireccionUsu.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["direccion"].Value);
                if (Convert.ToString(dgvUsuario.CurrentRow.Cells["sexo"].Value) == "M")
                {
                    cmbSexo.Text = "Masculino";
                }
                else if(Convert.ToString(dgvUsuario.CurrentRow.Cells["sexo"].Value) == "F")
                {
                    cmbSexo.Text = "Femenino";
                }
                if (Convert.ToString(dgvUsuario.CurrentRow.Cells["estado"].Value) == "A")
                {
                    cmbEstado.Text = "Activo";
                }
                else if(Convert.ToString(dgvUsuario.CurrentRow.Cells["estado"].Value) == "I")
                {
                    cmbEstado.Text = "Inactivo";
                }
                
                cmbEstado.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["estado"].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione desde la primera celda...");
            }
        }

        private void dgvUsuario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvUsuario.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkEliminar = (DataGridViewCheckBoxCell)dgvUsuario.Rows[e.RowIndex].Cells["Seleccionar"];
                chkEliminar.Value = !Convert.ToBoolean(chkEliminar.Value);
            }
        }
    }
}
