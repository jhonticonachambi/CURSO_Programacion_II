﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using Negocios;

using System.Data.SqlClient;
using System.Web.UI.WebControls;


namespace Presentacion
{
    public partial class FrmPedidoVentas : Form
    {
        public FrmPedidoVentas()
        {
            InitializeComponent();
        }
       
        private void Titulos2()
        {
            dgvVenta.Columns[0].Visible = false;
            dgvVenta.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[10].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[11].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[12].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[13].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[14].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvVenta.Columns[15].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;

            dgvVenta.Columns[1].HeaderText = "Id";
            dgvVenta.Columns[2].HeaderText = "Categoria";
            dgvVenta.Columns[3].HeaderText = "Producto";
            dgvVenta.Columns[4].HeaderText = "Mesa";
            dgvVenta.Columns[5].HeaderText = "Cliente";
            dgvVenta.Columns[6].HeaderText = "Nro Dni";
            dgvVenta.Columns[7].HeaderText = "Telefono";
            dgvVenta.Columns[8].HeaderText = "Direccion";
            dgvVenta.Columns[9].HeaderText = "Cantidad";
            dgvVenta.Columns[10].HeaderText = "Precio/Uni";
            dgvVenta.Columns[11].HeaderText = "Estado";
            dgvVenta.Columns[12].HeaderText = "Fecha";
            dgvVenta.Columns[13].HeaderText = "Subtotal";
            dgvVenta.Columns[14].HeaderText = "IGV";
            dgvVenta.Columns[15].HeaderText = "Total";
        }
        private void TitulosGrilla()
        {
            
            dgvPedido.Columns[0].Visible = false;
            dgvPedido.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[9].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[10].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvPedido.Columns[11].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;

            dgvPedido.Columns[1].HeaderText = "Id";
            dgvPedido.Columns[2].HeaderText = "Categoria";
            dgvPedido.Columns[3].HeaderText = "Producto";
            dgvPedido.Columns[4].HeaderText = "Mesa";
            dgvPedido.Columns[5].HeaderText = "Cliente";
            dgvPedido.Columns[6].HeaderText = "Nro Dni";
            dgvPedido.Columns[7].HeaderText = "Telefono";
            dgvPedido.Columns[8].HeaderText = "Direccion";
            dgvPedido.Columns[9].HeaderText = "Cantidad";
            dgvPedido.Columns[10].HeaderText = "Estado";
            dgvPedido.Columns[11].HeaderText = "Fecha";

            
            
        }
        



        private void Listar()
        {
            try
            {
                dgvPedido.DataSource = PedidoNegocio.Listar();
                this.TitulosGrilla();
                /*lblCantidad.Text = "Total de registro: " + Convert.ToString(dgvUsuario.Rows.Count);*/
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }


        private void Limpiar()
        {
                txtCliente.Clear();
                txtDni.Clear();
                txtDireccion.Clear();
                txtCantidad.Clear();
            
        }
        private void Listar2()
        {
            try
            {
                dgvVenta.DataSource = VentaNegocio.Listar();
                this.Titulos2();
                //lblCantidad.Text = "Total de registro: " + Convert.ToString(dgvUsuario.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }
        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void Buscar()
        {
            try
            {
                string buscar;
                buscar = txtCliente_Dni.Text;
                dgvVenta.DataSource = VentaNegocio.Buscar(buscar);
                double sub = 0;
                double igv = 0;
                double total = 0;
                foreach (DataGridViewRow row in dgvVenta.Rows)
                {
                    sub += Convert.ToDouble(row.Cells[13].Value);
                    txtSubtotal.Text = sub.ToString();
                    igv += Convert.ToDouble(row.Cells[14].Value);
                    txtIgv.Text = igv.ToString();
                    total += Convert.ToDouble(row.Cells[15].Value);
                    txtTotal.Text = total.ToString();
                }
               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void FrmVentas_Load(object sender, EventArgs e)
        {
            double sub = 0;
            double igv = 0;
            double total = 0;
            
            dgvPedido.Columns[0].Visible = false;
                this.ListarCategoria();
                this.ListarProductos();
                this.ListarMesas();
                this.Listar();
                this.Listar2();
            foreach (DataGridViewRow row in dgvVenta.Rows)
            {
                sub += Convert.ToDouble(row.Cells[13].Value);
                txtSubtotal.Text = sub.ToString();
                igv += Convert.ToDouble(row.Cells[14].Value);
                txtIgv.Text = igv.ToString();
                total += Convert.ToDouble(row.Cells[15].Value);
                txtTotal.Text = total.ToString();
            }
        }

        private void ListarCategoria()
        {
            

            cmbCategoria.DataSource = PedidoNegocio.ComboCategoria();
            cmbCategoria.DisplayMember = "nombre_categoria";
            cmbCategoria.ValueMember = "id_categoria";

        }
        private void ListarProductos()
        {

            cmbProducto.DataSource = PedidoNegocio.ComboProducto();
            cmbProducto.DisplayMember = "nombre_producto";
            cmbProducto.ValueMember = "id_producto";

        }
        private void ListarMesas()
        {

            cmbMesas.DataSource = PedidoNegocio.ComboMesa();
            cmbMesas.DisplayMember = "numero";
            cmbMesas.ValueMember = "id_mesa";

        }


      

        private void cmbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroTabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";
                int codigo;
                if (txtCliente.Text == string.Empty)
                {
                    MessageBox.Show("Por favor rellene el campo...");
                }
                else
                {
                    rpta = PedidoNegocio.Insertar(Convert.ToInt32(cmbCategoria.SelectedValue),Convert.ToInt32(cmbProducto.SelectedValue), Convert.ToInt32(cmbMesas.SelectedValue),
                        txtCliente.Text, txtDni.Text.Trim(),
                        txtTelefono.Text.Trim(), txtDireccion.Text,Convert.ToInt32(txtCantidad.Text),"Pendiente",String.Format(DateTime.Now.ToShortDateString()));
                    codigo = Convert.ToInt32(cmbMesas.SelectedValue);
                    rpta = PedidoNegocio.Ocupado(codigo);
                    if (rpta.Equals("OK"))
                    {
                        MessageBox.Show("Guardado correctamente");
                        this.Limpiar();
                        this.Listar();
                        this.Listar2();
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }                 
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void metroGrid2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvPedido.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkEliminar = (DataGridViewCheckBoxCell)dgvPedido.Rows[e.RowIndex].Cells["Seleccionar"];
                chkEliminar.Value = !Convert.ToBoolean(chkEliminar.Value);
            }
        }

        private void metroGrid2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de eliminar el(los) registro(s)", "Sistema Restaurante", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo, codigo2;
                    string rpta = "";

                    foreach (DataGridViewRow row in dgvPedido.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = PedidoNegocio.Eliminar(codigo);
                            codigo2= Convert.ToInt32(row.Cells[4].Value);
                            rpta = PedidoNegocio.Desocupado(codigo2);

                            if (rpta == "OK")
                            {
                                MessageBox.Show("Se elimino el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                
                                chkSeleccion.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }


        private void chkSeleccion_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccion.Checked)
            {
                dgvPedido.Columns[0].Visible = true;
                Limpiar();
            }
            else
            {
                dgvPedido.Columns[0].Visible = false;
            }
        }

        private void dgvPedido_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvPedido.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkEliminar = (DataGridViewCheckBoxCell)dgvPedido.Rows[e.RowIndex].Cells["Seleccionar"];
                chkEliminar.Value = !Convert.ToBoolean(chkEliminar.Value);
            }
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";
                string rpta2 = "";
                int codigo, codigo2;
                
                    foreach (DataGridViewRow row in dgvVenta.Rows)
                    {
                        foreach (DataGridViewRow row1 in dgvPedido.Rows)
                        {
                        codigo2 = Convert.ToInt32(row1.Cells[4].Value);
                        rpta = PedidoNegocio.Desocupado(codigo2);
                        
                        }
                        rpta = VentaNegocio.Insertar(Convert.ToInt32(row.Cells[1].Value), row.Cells[2].Value.ToString(), row.Cells[3].Value.ToString(), row.Cells[4].Value.ToString(), row.Cells[5].Value.ToString(), row.Cells[6].Value.ToString(), row.Cells[7].Value.ToString(), row.Cells[8].Value.ToString(), Convert.ToInt32(row.Cells[9].Value), row.Cells[10].Value.ToString(), "Cancelado", row.Cells[12].Value.ToString(), row.Cells[13].Value.ToString(), row.Cells[14].Value.ToString(), row.Cells[15].Value.ToString());
                        codigo = Convert.ToInt32(row.Cells[1].Value);
                        rpta2 = VentaNegocio.Pagar(codigo);
                        if (rpta.Equals("OK"))
                        {
                            MessageBox.Show("Guardado correctamente");
                        }
                        else
                        {
                            MessageBox.Show(rpta);
                        }
                    }
                Listar2();
                Listar();
                txtCliente_Dni.Clear();
                double sub = 0;
                double igv = 0;
                double total = 0;
                foreach (DataGridViewRow row in dgvVenta.Rows)
                {
                    sub += Convert.ToDouble(row.Cells[13].Value);
                    txtSubtotal.Text = sub.ToString();
                    igv += Convert.ToDouble(row.Cells[14].Value);
                    txtIgv.Text = igv.ToString();
                    total += Convert.ToDouble(row.Cells[15].Value);
                    txtTotal.Text = total.ToString();
                }
                double a, b;
                a = Convert.ToDouble(txtRecibido.Text);
                b = Convert.ToDouble(txtTotal.Text);
                lbl1.Text = (a - b).ToString();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar();
            
        }
    }
}
