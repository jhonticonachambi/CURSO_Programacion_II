﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Web.UI.WebControls;
using Negocios;
using System.Data.SqlClient;




namespace Presentacion
{
    public partial class FrmMesa : Form
    {
        public FrmMesa()
        {
            InitializeComponent();
        }

        
        private void Buscar()
        {
            try
            {
                string Buscar;
                Buscar = txtBuscar.Text;
                dgvMesa.DataSource = MesaNegocio.Buscar(Buscar);

                this.Formatear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void Formatear()
        {
            
            dgvMesa.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvMesa.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvMesa.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;

            dgvMesa.Columns[0].HeaderText = "Id";
            dgvMesa.Columns[1].HeaderText = "Numero";
            dgvMesa.Columns[2].HeaderText = "Estado";
        }
        private void Limpiar()
        {
            txtnroMesa.Clear();
        }
        private void Listar()
        {
            try
            {

                dgvMesa.DataSource = MesaNegocio.Listar();
                this.Formatear();
                this.Limpiar();
                lblTotalMesas.Text = Convert.ToString(dgvMesa.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }






        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";
                if (txtnroMesa.Text == string.Empty)
                {
                    MessageBox.Show("Por favor rellene el campo...");
                }
                else
                {
                    rpta = MesaNegocio.Insertar(Convert.ToInt32(txtnroMesa.Text.Trim()),"Disponible");
                    if (rpta.Equals("OK"))
                    {
                        MessageBox.Show("Guardado correctamente");
                        this.Listar();
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            this.Listar();

            txtnroMesa.Text = Convert.ToString(dgvMesa.Rows.Count + 1);
        }

      

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de eliminar el(los) registro(s)", "Sistema Escritorio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta="";
                    int valor;

                    valor = dgvMesa.Rows.Count;
                    codigo = Convert.ToInt32(dgvMesa.Rows[valor - 1].Cells[1].Value);



                            rpta = MesaNegocio.Eliminar(codigo);

                      
                    }
                    this.Listar();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }


        private void btnBuscarMesa_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }


        private void FrmMesa_Load(object sender, EventArgs e)
        {
            this.dgvMesa.AllowUserToAddRows = false;
            this.Listar();

            txtnroMesa.Text = Convert.ToString(dgvMesa.Rows.Count+1);
            txtnroMesa.Enabled = false;

        }
    }
}
