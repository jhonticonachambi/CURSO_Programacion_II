﻿using Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FrmProducto : Form
    {
        public FrmProducto()
        {
            InitializeComponent();
        }
        /* METODOS*/

        private void Cargarcomboestado()
        {
            cmbEstado.Items.Clear();
            cmbEstado.Items.Add(new ListItem("Activo", "A"));
            cmbEstado.Items.Add(new ListItem("Inactivo", "I"));
        }

        private void TitulosGrilla()
        {
            dgvUsuario.Columns[0].Visible = false; //Columna Seleccionar
            dgvUsuario.Columns[0].Visible = false; //Columna Seleccionar
            dgvUsuario.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dgvUsuario.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvUsuario.Columns[1].HeaderText = "Código";
            dgvUsuario.Columns[2].HeaderText = "Categoria";
            dgvUsuario.Columns[3].HeaderText = "NombroProducto";
            dgvUsuario.Columns[4].HeaderText = "Descripcion";
            dgvUsuario.Columns[5].HeaderText = "Precio";
            dgvUsuario.Columns[6].HeaderText = "Estado";
        }
        private void Listar()
        {
            try
            {
                dgvUsuario.DataSource = ProductoNegocio.Listar();
                this.TitulosGrilla();
                lblCantidad.Text = "Total de registro: " + Convert.ToString(dgvUsuario.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }
        private void Visualizar()
        {
            btnEliminar.Visible = false;
            btnModificar.Visible = false;
            btnCancelar.Visible = false;
            btnActivar.Visible = false;
            btnDesactivar.Visible = false;
            dgvUsuario.Columns[0].Visible = false;
        }
        private void ListarCombo()
        {
            try
            {
                cmbCategoria.DataSource = ProductoNegocio.Combo();
                cmbCategoria.DisplayMember = "nombre_categoria";
                cmbCategoria.ValueMember = "id_categoria";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void Limpiar()
        {
            txtPrecio.Clear();
            txtcodigo.Clear();
            txtDescripcion.Clear();
            txtProducto.Clear();
            cmbCategoria.Text = "";
            cmbEstado.Text = "";
        }
        private void Buscar()
        {
            try
            {
                string buscar;
                buscar = txtBuscar.Text;
                dgvUsuario.DataSource = ProductoNegocio.Buscar(buscar);
                this.TitulosGrilla();
                lblCantidad.Text = "Total de registro: " + Convert.ToString(dgvUsuario.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";
                if (txtProducto.Text == string.Empty)
                {
                    MessageBox.Show("Por favor rellene el campo...");
                }
                else
                {
                    rpta = ProductoNegocio.Insertar(Convert.ToInt32(cmbCategoria.SelectedValue), txtProducto.Text, txtDescripcion.Text, txtPrecio.Text, cmbEstado.Text);
                    if (rpta.Equals("OK"))
                    {
                        MessageBox.Show("Guardado correctamente");
                        this.Limpiar();
                        this.Visualizar();
                        this.Listar();
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void dgvUsuario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvUsuario.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkEliminar = (DataGridViewCheckBoxCell)dgvUsuario.Rows[e.RowIndex].Cells["Seleccionar"];
                chkEliminar.Value = !Convert.ToBoolean(chkEliminar.Value);
            }
        }

        private void dgvUsuario_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                btnModificar.Visible = true;
                btnCancelar.Visible = true;
                btnGuardar.Visible = false;
                txtcodigo.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["id_producto"].Value);
                cmbCategoria.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["nombre_categoria"].Value);
                txtProducto.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["nombre_producto"].Value);               
                txtDescripcion.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["descripcion"].Value);
                txtPrecio.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["precio"].Value);
                if (Convert.ToString(dgvUsuario.CurrentRow.Cells["estado"].Value) == "A")
                {
                    cmbEstado.Text = "Activo";
                }
                else if (Convert.ToString(dgvUsuario.CurrentRow.Cells["estado"].Value) == "I")
                {
                    cmbEstado.Text = "Inactivo";
                }

                cmbEstado.Text = Convert.ToString(dgvUsuario.CurrentRow.Cells["estado"].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione desde la primera celda...");
            }
        }

        private void metroCheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                dgvUsuario.Columns[0].Visible = true;
                btnGuardar.Visible = false;
                btnModificar.Visible = false;
                btnEliminar.Visible = true;
                btnCancelar.Visible = true;
                btnActivar.Visible = true;
                btnDesactivar.Visible = true;
                Limpiar();
            }
            else
            {
                dgvUsuario.Columns[0].Visible = false;
                btnGuardar.Visible = true;
                btnEliminar.Visible = false;
                btnCancelar.Visible = false;
                btnActivar.Visible = false;
                btnDesactivar.Visible = false;
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";

                if (txtProducto.Text == string.Empty)
                {
                    MessageBox.Show("Por favor complete el campo");
                }
                else
                {
                    rpta = ProductoNegocio.Actualizar(Convert.ToInt32(txtcodigo.Text.Trim()), Convert.ToInt32(cmbCategoria.SelectedValue), txtProducto.Text, txtDescripcion.Text, txtPrecio.Text, cmbEstado.Text);

                    if (rpta.Equals("OK"))
                    {
                        MessageBox.Show("Actualizado correctamente");
                        this.Limpiar();
                        this.Listar();
                        btnGuardar.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de eliminar el(los) registro(s)", "Sistema Restaurante", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta = "";

                    foreach (DataGridViewRow row in dgvUsuario.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = ProductoNegocio.Eliminar(codigo);

                            if (rpta == "OK")
                            {
                                MessageBox.Show("Se elimino el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                btnEliminar.Visible = false;
                                btnGuardar.Visible = true;
                                chkSeleccionar.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
            btnEliminar.Visible = false;
            btnCancelar.Visible = false;
            btnGuardar.Visible = true;
            btnModificar.Visible = false;
            chkSeleccionar.Checked = false;
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de activar el(los) registro(s)", "Sistema Escritorio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta = "";

                    foreach (DataGridViewRow row in dgvUsuario.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = ProductoNegocio.Activar(codigo);

                            if (rpta == "OK")
                            {
                                MessageBox.Show("Se activo el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                chkSeleccionar.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de desactivar el(los) registro(s)", "Sistema Escritorio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta = "";

                    foreach (DataGridViewRow row in dgvUsuario.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = ProductoNegocio.Desactivar(codigo);

                            if (rpta == "OK")
                            {
                                MessageBox.Show("Se desactivo el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                chkSeleccionar.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }

        private void FrmProducto_Load(object sender, EventArgs e)
        {
            this.ListarCombo();
            this.Cargarcomboestado();
            this.Visualizar();
            this.Listar();
            txtcodigo.Enabled = false;
        }
    }
}
