﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace Presentacion
{
    public partial class FrmLogin : MetroFramework.Forms.MetroForm
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }


        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            try
            {
                string Usuario, Password;
                Usuario = txtUsuario.Text.Trim();
                Password = txtContraseña.Text.Trim();
                DataTable Tabla = new DataTable();
                Tabla = UsuarioNegocio.Login(Usuario, Password);
                if (Tabla.Rows.Count <= 0)
                {
                    MessageBox.Show("Usuario y/o contraseña Incorrectos...", "Acceso al Sistema",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (Convert.ToString(Tabla.Rows[0][5]) == "I")
                    {
                        MessageBox.Show("El usuario esta Inhabilitado...", "Acceso al Sistema",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("Bienvenido al Sistema: " + "( " + Convert.ToString(Tabla.Rows[0][4]) + " ) " + Convert.ToString(Tabla.Rows[0][6]) + " " + Convert.ToString(Tabla.Rows[0][7]));
                        Principal frm = new Principal();
                        frm.nombre = Tabla.Rows[0][6].ToString();
                        frm.apellido = Tabla.Rows[0][7].ToString();
                        frm.cargo = Convert.ToString(Tabla.Rows[0][4]);
                        frm.Show();
                        this.Hide();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
