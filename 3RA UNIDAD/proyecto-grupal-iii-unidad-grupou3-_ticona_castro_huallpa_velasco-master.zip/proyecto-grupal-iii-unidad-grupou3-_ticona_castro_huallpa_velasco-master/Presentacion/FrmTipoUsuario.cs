﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace Presentacion
{
    public partial class FrmTipoUsuario : Form
    {
        public FrmTipoUsuario()
        {
            InitializeComponent();
        }
        //METODO BUSCAR
        private void Buscar()
        {
            try
            {
                string Buscar;
                Buscar = txtBuscar.Text;
                dataGridView1.DataSource = TipoUsuarioNegocio.Buscar(Buscar);

                this.Formatear();
                lblCantidad.Text = "Total de registros: " + Convert.ToString(dataGridView1.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        //METODO LIMPIAR
        private void Limpiar()
        {
            txtNombreUsu.Text = "";
            txtId.Text = "";
        }
        //METODO VISUALIZAR
        private void Visualizar()
        {
            btnEliminar.Visible = false;
            btnModificar.Visible = false;
            btnCancelar.Visible = false;
            dataGridView1.Columns[0].Visible = false;
        }
        //METODO FORMATEAR
        private void Formatear()
        {
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dataGridView1.Columns[1].HeaderText = "IdTipoUsuario";
            dataGridView1.Columns[2].HeaderText = "Descripcion";
        }
        //METODOD LISTAR
        private void Listar()
        {
            try
            {
                dataGridView1.DataSource = TipoUsuarioNegocio.Listar();
                this.Formatear();
                this.Limpiar();
                this.Visualizar();
                lblCantidad.Text = "Total de registros: " + Convert.ToString(dataGridView1.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        //FRM TIPO USUARIO
        private void FrmTipoUsuario_Load(object sender, EventArgs e)
        {
            this.dataGridView1.AllowUserToAddRows = false;
            this.Listar();
            txtId.Enabled = false;
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView1.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkEliminar = (DataGridViewCheckBoxCell)dataGridView1.Rows[e.RowIndex].Cells["Seleccionar"];
                chkEliminar.Value = !Convert.ToBoolean(chkEliminar.Value);
            }
        }

        /*   REFERENCIAS   */
        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";
                if (txtNombreUsu.Text == string.Empty)
                {
                    MessageBox.Show("Por favor rellene el campo...");
                }
                else
                {
                    rpta = TipoUsuarioNegocio.Insertar(txtNombreUsu.Text.Trim());
                    if (rpta.Equals("Correcto"))
                    {
                        MessageBox.Show("Guardado correctamente");
                        this.Limpiar();
                        this.Visualizar();
                        this.Listar();
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnModificar_Click_1(object sender, EventArgs e)
        {
            try
            {
                string rpta = "";

                if (txtNombreUsu.Text == string.Empty)
                {
                    MessageBox.Show("Por favor complete el campo");
                }
                else
                {
                    rpta = TipoUsuarioNegocio.Actualizar(Convert.ToInt32(txtId.Text), txtNombreUsu.Text.Trim());

                    if (rpta.Equals("Correcto"))
                    {
                        MessageBox.Show("Actualizado correctamente");
                        this.Limpiar();
                        this.Listar();
                        btnGuardar.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show(rpta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnEliminar_Click_1(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Seguro de eliminar el(los) registro(s)", "Sistema Escritorio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (opcion == DialogResult.OK)
                {
                    int codigo;
                    string rpta = "";

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            rpta = TipoUsuarioNegocio.Eliminar(codigo);

                            if (rpta == "Correcto")
                            {
                                MessageBox.Show("Se elimino el registro satisfactoriamente: " + Convert.ToString(row.Cells[1].Value));
                                btnEliminar.Visible = false;
                                btnGuardar.Visible = true;
                                chkSeleccionar.Checked = false;
                            }
                            else
                            {
                                MessageBox.Show(rpta);
                            }
                        }
                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            Limpiar();
            btnEliminar.Visible = false;
            btnCancelar.Visible = false;
            btnGuardar.Visible = true;
            btnModificar.Visible = false;
            chkSeleccionar.Checked = false;
        }

        private void btnBuscar_Click_1(object sender, EventArgs e)
        {
            this.Buscar();
        }

        private void dataGridView1_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                btnModificar.Visible = true;
                btnCancelar.Visible = true;
                btnGuardar.Visible = false;
                txtId.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["id_tipo_usuario"].Value);
                txtNombreUsu.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["descripcion"].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione desde la celda Id");
            }
        }

        private void chkSeleccionar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                dataGridView1.Columns[0].Visible = true;
                btnGuardar.Visible = false;
                btnModificar.Visible = false;
                btnEliminar.Visible = true;
                btnCancelar.Visible = true;
                Limpiar();
            }
            else
            {
                dataGridView1.Columns[0].Visible = false;
                btnGuardar.Visible = true;
                btnEliminar.Visible = false;
                btnCancelar.Visible = false;
            }
        }
    }
}
