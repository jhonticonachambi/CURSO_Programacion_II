﻿using DGVPrinterHelper;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WhatsAppApi;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using Telegram.Bot;
using Telegram.Bot.Args;
using Telegram.Bot.Types.InputFiles;

namespace Presentacion
{
    public partial class FrmMenuDelDia : Form
    {
        static TelegramBotClient Bot = new TelegramBotClient("1463840223:AAEfaB_oa8iEKTOlaQSuUIHaTmlfdH06yxE");
        static string pdf = @"C:\Users\Andree Velasco\Documents\Menu del Dia.pdf";
        public FrmMenuDelDia()
        {
            InitializeComponent();
            Bot.StartReceiving();
            Bot.OnMessage += Bot_OnMessage;
        }

        private static async void Bot_OnMessage(object sender, MessageEventArgs e)
        {
            
            if (e.Message.Text.StartsWith("/Carta"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Menu del Dia");
                using (var stream = File.OpenRead(pdf))
                {
                    InputOnlineFile input = new InputOnlineFile(stream);
                    await Bot.SendDocumentAsync(e.Message.Chat.Id, input);
                }
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Brindenos sus Datos para proceder con el pedido: ");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Inserte sus datos luego del respectivo comando.");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/NombreApellidos");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/DNI");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Telefono");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Direccion");
                
            }
            else if (e.Message.Text.StartsWith("/Categorias"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Sopas");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Entradas");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Fondos");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Postres");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Bebidas");
                
            }
            else if (e.Message.Text.StartsWith("/Entradas"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Elija el Plato seguido de la cantidad: ");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Ceviche");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/CausaRellena");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/PapaRellena");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Categorias");
                
            }
            else if (e.Message.Text.StartsWith("/Sopas"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Elija el Plato seguido de la cantidad: ");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/CaldoDeGallina");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/SopaDeQuinua");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/CaldoDeCordero");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Categorias");
                
            }
            else if (e.Message.Text.StartsWith("/Fondos"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Elija el Plato seguido de la cantidad: ");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/SecoDeCordero");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/PicanteAlaTacneña");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/ChicharronDeChancho");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Categorias");
                
            }
            else if (e.Message.Text.StartsWith("/Postres"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Elija el Plato seguido de la cantidad: ");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/SuspiroAlaLimeña");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Gelatina");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Helado");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Categorias");
                
            }
            else if (e.Message.Text.StartsWith("/Bebidas"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Elija el Plato seguido de la cantidad: ");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/CocaCola1Lt.");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Fanta2Lt.");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/InkaKola1Lt.");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/JugoDeNaranja1Lt.");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/ChichaMaracuya1Lt.");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Categorias");
                
            }
            else if (e.Message.Text.StartsWith("/Horarios"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Lunes:       08:00 - 22:00");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Martes:      08:00 - 22:00");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Miercoles:   08:00 - 22:00");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Jueves:      08:00 - 22:00");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Viernes:     08:00 - 22:00");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Sabado:      08:00 - 17:00");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Domingos:    No atendemos");
                
            }
            else if (e.Message.Text.StartsWith("/Comandos"))
            {
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Carta");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Categorias");
                await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Horarios");
            }
            await Bot.SendTextMessageAsync(e.Message.Chat.Id, "/Comandos");
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter();
            printer.Title = "Menu del Dia";
            printer.SubTitle = string.Format("Fecha: {0}", DateTime.Now.Date.ToString("dd/MM/yyyy"));
            printer.TitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.PorportionalColumns = true;
            printer.HeaderCellAlignment = StringAlignment.Near;
            printer.Footer = "LA HEROICA, los mejores en el rubro Culinario";
            printer.FooterColor = Color.LightGray;
            printer.SubTitleSpacing = 15;
            printer.FooterSpacing = 15;
            printer.SubTitleColor = Color.Gray;
            printer.printDocument.DefaultPageSettings.Landscape = true;
            printer.PrintDataGridView(metroGrid1);
        }
        private void Titulos()
        {
            metroGrid1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            metroGrid1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            metroGrid1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            metroGrid1.Columns[0].HeaderText = "Categoria";
            metroGrid1.Columns[1].HeaderText = "Producto";
            metroGrid1.Columns[2].HeaderText = "Precio S/.";
        }
        private void WhatsApp_Load(object sender, EventArgs e)
        {
            SqlConnection sqlCon;
            string conString = null;
            string sqlQuery = null;

            conString = "Data Source=.;Initial Catalog=db_restaurante;Integrated Security=SSPI;";
            sqlCon = new SqlConnection(conString);
            sqlCon.Open();
            sqlQuery = "USP_Producto_PDF";
            SqlDataAdapter dscmd = new SqlDataAdapter(sqlQuery, sqlCon);
            DataTable dtData = new DataTable();
            dscmd.Fill(dtData);
            metroGrid1.DataSource = dtData;
            Titulos();
        }       
    }
}
