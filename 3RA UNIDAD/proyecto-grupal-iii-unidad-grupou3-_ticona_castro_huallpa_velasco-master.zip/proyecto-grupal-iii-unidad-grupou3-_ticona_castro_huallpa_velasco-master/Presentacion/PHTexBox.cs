﻿using System.Windows.Forms;

namespace Presentacion
{
    internal class PHTexBox : TextBox
    {
        private string v;

        public PHTexBox(string v)
        {
            this.v = v;
        }
    }
}