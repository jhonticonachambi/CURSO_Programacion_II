﻿using AccesoDatos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class CategoriaNegocio
    {
        public static DataTable Listar()
        {
            CategoriaDatos obj = new CategoriaDatos();
            return obj.Listar();
        }
        public static DataTable Buscar(string Busqueda)
        {
            CategoriaDatos obj = new CategoriaDatos();
            return obj.Buscar(Busqueda);
        }
        public static string Insertar(string nombre)
        {
            string Existe;
            CategoriaDatos obj = new CategoriaDatos();

            Existe = obj.Existe(nombre);
            if (Existe.Equals("1"))
            {
                return "El Cargo ya existe en la BD....";
            }
            else
            {
                CategoriaEntidad objE = new CategoriaEntidad();
                objE.nombre_categoria = nombre;
                return obj.Insertar(objE);
            }
        }

        //Metodo Actualizar
        public static string Actualizar(int Id, string nombre)
        {
            CategoriaDatos obj = new CategoriaDatos();

            string existe = obj.Existe(Id.ToString());
            if (existe.Equals("1"))
            {
                return "No se pudo actualizar...";
            }
            else
            {
                CategoriaEntidad objent = new CategoriaEntidad();
                objent.id_categoria = Id;
                objent.nombre_categoria = nombre;
                return obj.Actualizar(objent);
            }
        }

        //Metodo Eliminar
        public static string Eliminar(int Id)
        {
            CategoriaDatos obj = new CategoriaDatos();
            return obj.Eliminar(Id);
        }
    }
}
