﻿using AccesoDatos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class VentaNegocio
    {
        public static DataTable Listar()
        {
            VentaDatos obj = new VentaDatos();
            return obj.Listar();
        }
        public static string Insertar(int idpedido, string categoria, string idproducto, string idmesa, string cliente, string num_documento, string telefono, string direccion, int cantidad, string preciouni, string estado, string fecha, string subtotal, string igv, string total)
        {
            VentaDatos obj = new VentaDatos();

            string existe = obj.Existe(idpedido.ToString());

            if (existe.Equals("1"))
            {
                VentaEntidad objent = new VentaEntidad();
                objent.id_pedido = idpedido;
                objent.categoria = categoria;
                objent.producto = idproducto;
                objent.mesa = idmesa;
                objent.cliente = cliente;
                objent.nro_documento = num_documento;
                objent.telefono = telefono;
                objent.direccion = direccion;
                objent.cantidad = cantidad;
                objent.preciounitario = preciouni;
                objent.estado = estado;
                objent.fecha = fecha;
                objent.subtotal = subtotal;
                objent.igv = igv;
                objent.total = total;
                return obj.Insertar(objent);
            }
            else
            {
                VentaEntidad objent = new VentaEntidad();
                objent.id_pedido = idpedido;
                objent.categoria = categoria;
                objent.producto = idproducto;
                objent.mesa = idmesa;
                objent.cliente = cliente;
                objent.nro_documento = num_documento;
                objent.telefono = telefono;
                objent.direccion = direccion;
                objent.cantidad = cantidad;
                objent.preciounitario = preciouni;
                objent.estado = estado;
                objent.fecha = fecha;
                objent.subtotal = subtotal;
                objent.igv = igv;
                objent.total = total;
                return obj.Insertar(objent);
            }
        }
        public static string Pagar(int id)
        {
            VentaDatos obj = new VentaDatos();
            return obj.Pagar(id);
        }

        public static string Pendiente(int id)
        {
            VentaDatos obj = new VentaDatos();
            return obj.Pendiente(id);
        }
        public static DataTable Buscar(string busqueda)
        {
            VentaDatos obj = new VentaDatos();
            return obj.Buscar(busqueda);
        }
    }
    
}
