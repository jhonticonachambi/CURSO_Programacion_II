﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using AccesoDatos;
using Entidades;

namespace Negocios
{
    public class PedidoNegocio
    {

        public static DataTable ComboCategoria()
        {
            PedidoDatos obj = new PedidoDatos();
            return obj.ComboCategorias();
        }
        public static DataTable ComboProducto()
        {
            PedidoDatos obj = new PedidoDatos();

            return obj.ComboProducto();
        }

        public static DataTable ComboMesa()
        {
            PedidoDatos obj = new PedidoDatos();

            return obj.ComboMesas();
        }

        

        public static DataTable Buscar(string busqueda)
        {
            PedidoDatos obj = new PedidoDatos();
            return obj.Buscar(busqueda);
        }

        public static string Eliminar(int id)
        {
            PedidoDatos obj = new PedidoDatos();
            return obj.Eliminar(id);
        }

        

        // *------------------------------------jhom

        public static DataTable Listar()
        {
            PedidoDatos obj = new PedidoDatos();
            return obj.Listar();
        }

        public static string Insertar(int idcategoria, int idproducto,int idmesa,  string cliente, string num_documento, string telefono, string direccion, int cantidad,string estados,string fecha)
        {
            PedidoDatos obj = new PedidoDatos();

            string existe = obj.Existe(cliente);

            if (existe.Equals("1"))
            {
                PedidoEntidad objent = new PedidoEntidad();
                objent.id_categoria = idcategoria;
                objent.id_producto = idproducto;
                objent.id_mesa = idmesa;
                objent.cliente = cliente;
                objent.nro_documento = num_documento;
                objent.telefono = telefono;
                objent.direccion = direccion;
                objent.cantidad = cantidad;
                objent.estado = estados;
                objent.fecha = fecha;
                return obj.Insertar(objent);
            }
            else
            {
                PedidoEntidad objent = new PedidoEntidad();
                objent.id_categoria = idcategoria;
                objent.id_producto = idproducto;
                objent.id_mesa = idmesa;
                objent.cliente = cliente;
                objent.nro_documento = num_documento;
                objent.telefono = telefono;
                objent.direccion = direccion;
                objent.cantidad = cantidad;
                objent.estado = estados;
                objent.fecha = fecha;
                return obj.Insertar(objent);
            }


        }


        public static string Ocupado(int id)
        {
            PedidoDatos obj = new PedidoDatos();
            return obj.Ocupado(id);
        }

        public static string Desocupado(int id)
        {
            PedidoDatos obj = new PedidoDatos();
            return obj.Desocupado(id);
        }



    }
}
