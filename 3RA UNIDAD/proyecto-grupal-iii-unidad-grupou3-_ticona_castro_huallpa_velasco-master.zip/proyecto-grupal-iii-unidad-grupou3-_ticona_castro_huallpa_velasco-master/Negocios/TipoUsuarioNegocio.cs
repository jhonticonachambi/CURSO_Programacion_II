﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using AccesoDatos;
using Entidades;

namespace Negocios
{
    public class TipoUsuarioNegocio
    {
        public static DataTable Listar()
        {
            TipoUsuarioDatos obj = new TipoUsuarioDatos();
            return obj.Listar();
        }
        public static DataTable Buscar(string Busqueda)
        {
            TipoUsuarioDatos obj = new TipoUsuarioDatos();
            return obj.Buscar(Busqueda);
        }
        public static string Insertar(string Descripcion)
        {
            string Existe;
            TipoUsuarioDatos obj = new TipoUsuarioDatos();

            Existe = obj.Existe(Descripcion);
            if (Existe.Equals("1"))
            {
                return "El Cargo ya existe en la BD....";
            }
            else
            {
                TipoUsuarioEntidad objE = new TipoUsuarioEntidad();
                objE.descripcion = Descripcion;
                return obj.Insertar(objE);
            }
        }

        //Metodo Actualizar
        public static string Actualizar(int Id, string Descripcion)
        {
            TipoUsuarioDatos obj = new TipoUsuarioDatos();

            string existe = obj.Existe(Id.ToString());
            if (existe.Equals("1"))
            {
                return "No se pudo actualizar...";
            }
            else
            {
                TipoUsuarioEntidad objent = new TipoUsuarioEntidad();
                objent.tipousuario_id = Id;
                objent.descripcion = Descripcion;
                return obj.Actualizar(objent);
            }
        }

        //Metodo Eliminar
        public static string Eliminar(int Id)
        {
            TipoUsuarioDatos obj = new TipoUsuarioDatos();
            return obj.Eliminar(Id);
        }
    }
}
