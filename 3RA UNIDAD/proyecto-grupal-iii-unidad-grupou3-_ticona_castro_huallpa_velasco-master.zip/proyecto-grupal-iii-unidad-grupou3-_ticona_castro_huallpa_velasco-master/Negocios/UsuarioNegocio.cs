﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccesoDatos;
using Entidades;

namespace Negocios
{
    public class UsuarioNegocio
    {
        public static DataTable Combo()
        {
            UsuarioDatos obj = new UsuarioDatos();
            return obj.Combo();
        }
        public static DataTable Login(string Usuario, string Password)
        {
            UsuarioDatos objUsuario = new UsuarioDatos();
            return objUsuario.Login(Usuario, Password);
        }
        public static DataTable Listar()
        {
            UsuarioDatos obj = new UsuarioDatos();
            return obj.Listar();
        }

        public static DataTable Buscar(string busqueda)
        {
            UsuarioDatos obj = new UsuarioDatos();
            return obj.Buscar(busqueda);
        }

        public static string Insertar(int idtipo, string tipoident, string nroident, string nombres, string apellidos, string contraseña, string email, string celular, string direccion, string sexo, string estado)
        {
            UsuarioDatos obj = new UsuarioDatos();

            string existe = obj.Existe(nroident);
            if (existe.Equals("1"))
            {
                return "El Nro de Documento ya existe...";
            }
            else
            {
                UsuarioEntidad objent = new UsuarioEntidad();
                objent.id_tipo_usuario = idtipo;
                objent.tipo_identificacion = tipoident;
                objent.nro_identificacion = nroident;
                objent.nombres = nombres;
                objent.apellidos = apellidos;
                objent.contraseña = contraseña;
                objent.email = email;
                objent.celular = celular;
                objent.direccion = direccion;
                objent.sexo = sexo;
                objent.estado = estado;
                return obj.Insertar(objent);
            }
        }

        public static string Actualizar(int id, int idtipo, string tipoident, string nroident, string nombres, string apellidos, string contraseña, string email, string celular, string direccion, string sexo, string estado)
        {
            UsuarioDatos obj = new UsuarioDatos();

            string existe = obj.Existe(id.ToString());
            if (existe.Equals("1"))
            {
                UsuarioEntidad objent = new UsuarioEntidad();
                objent.id_usuario = id;
                objent.id_tipo_usuario = idtipo;
                objent.tipo_identificacion = tipoident;
                objent.nro_identificacion = nroident;
                objent.nombres = nombres;
                objent.apellidos = apellidos;
                objent.contraseña = contraseña;
                objent.email = email;
                objent.celular = celular;
                objent.direccion = direccion;
                objent.sexo = sexo;
                objent.estado = estado;
                return obj.Actualizar(objent);
            }
            else
            {
                return "El Nro de documento no existe en la BD...";
            }
        }

        public static string Eliminar(int id)
        {
            UsuarioDatos obj = new UsuarioDatos();
            return obj.Eliminar(id);
        }

        public static string Activar(int id)
        {
            UsuarioDatos obj = new UsuarioDatos();
            return obj.Activar(id);
        }

        public static string Desactivar(int id)
        {
            UsuarioDatos obj = new UsuarioDatos();
            return obj.Desactivar(id);
        }


    }
}
