﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data;
using AccesoDatos;
using Entidades;

namespace Negocios
{
    public class MesaNegocio
    {
        public static DataTable Listar()
        {
            MesaDatos obj = new MesaDatos();
            return obj.Listar();
        }

        public static DataTable Buscar(string Busqueda)
        {
            MesaDatos obj = new MesaDatos();
            return obj.Buscar(Busqueda);
        }


        public static string Insertar(int numero, string nestado)
        {
            string Existe;
            MesaDatos obj = new MesaDatos();

            Existe = obj.Existe(nestado);
            if (Existe.Equals("1"))
            {
                return "El Cargo ya existe en la BD....";
            }
            else
            {
                MesaEntidad objE = new MesaEntidad();
                objE.numero = numero;
                objE.estado = nestado;
                return obj.Insertar(objE);
            }
        }


        public static string Eliminar(int id)
        {
            MesaDatos obj = new MesaDatos();
            return obj.Eliminar(id);
        }







    }
}
