﻿using AccesoDatos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class ProductoNegocio
    {
        public static DataTable Combo()
        {
            ProductoDatos obj = new ProductoDatos();
            return obj.Combo();
        }     
        public static DataTable Listar()
        {
            ProductoDatos obj = new ProductoDatos();
            return obj.Listar();
        }

        public static DataTable Buscar(string busqueda)
        {
            ProductoDatos obj = new ProductoDatos();
            return obj.Buscar(busqueda);
        }

        public static string Insertar(int idcategoria, string nombre, string descripcion, string precio, string estado)
        {
            ProductoDatos obj = new ProductoDatos();

            string existe = obj.Existe(nombre);
            if (existe.Equals("1"))
            {
                return "El producto ya existe...";
            }
            else
            {
                ProductoEntidad objent = new ProductoEntidad();
                objent.id_categoria = idcategoria;
                objent.nombre_producto = nombre;
                objent.descripcion = descripcion;
                objent.precio = precio;
                objent.estado = estado;

                return obj.Insertar(objent);
            }
        }

        public static string Actualizar(int id, int idcategoria, string nombre, string descripcion, string precio, string estado)
        {
            ProductoDatos obj = new ProductoDatos();

            string existe = obj.Existe(id.ToString());
            if (existe.Equals("1"))
            {
                return "El producto no existe en la BD...";
            }
            else
            {
                ProductoEntidad objent = new ProductoEntidad();
                objent.id_producto = id;
                objent.id_categoria = idcategoria;
                objent.nombre_producto = nombre;
                objent.descripcion = descripcion;
                objent.precio = precio;
                objent.estado = estado;

                return obj.Actualizar(objent);
                
            }
        }

        public static string Eliminar(int id)
        {
            ProductoDatos obj = new ProductoDatos();
            return obj.Eliminar(id);
        }

        public static string Activar(int id)
        {
            ProductoDatos obj = new ProductoDatos();
            return obj.Activar(id);
        }

        public static string Desactivar(int id)
        {
            ProductoDatos obj = new ProductoDatos();
            return obj.Desactivar(id);
        }
    }
}
