﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos
{
    public class ProductoDatos
    {
        public DataTable Combo()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection SqlCnx = new SqlConnection();

            try
            {
                //Establecer conexion
                SqlCnx = Conexion.getInstancia().EstablecerConexion();
                //Llamar al procedimiento almacenado
                SqlCommand comando = new SqlCommand("USP_Categoria_S", SqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                SqlCnx.Open();
                Resultado = comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (SqlCnx.State == ConnectionState.Open) SqlCnx.Close();
            }

        }

        public DataTable Listar()
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            //Tabla.Columns[3].DataType = typeof(string);
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_S", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                sqlcnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
        }


        public DataTable Buscar(string busqueda)
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_S_Buscar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pbusqueda", SqlDbType.VarChar).Value = busqueda;
                sqlcnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
        }


        public string Existe(string valor)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_Verificar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pvalor", SqlDbType.VarChar).Value = valor;
                SqlParameter parExiste = new SqlParameter();
                parExiste.ParameterName = ("@existe");
                parExiste.SqlDbType = SqlDbType.Int;
                parExiste.Direction = ParameterDirection.Output;
                comando.Parameters.Add(parExiste);
                sqlcnx.Open();
                comando.ExecuteNonQuery();
                Rpta = Convert.ToString(parExiste.Value);
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }


        public string Insertar(ProductoEntidad obj)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_I", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_categoria", SqlDbType.Int).Value = obj.id_categoria;
                comando.Parameters.Add("@pnombre_producto", SqlDbType.VarChar).Value = obj.nombre_producto;
                comando.Parameters.Add("@pdescripcion", SqlDbType.VarChar).Value = obj.descripcion;
                comando.Parameters.Add("@pprecio", SqlDbType.VarChar).Value = obj.precio;
                comando.Parameters.Add("@pestado", SqlDbType.VarChar).Value = obj.estado;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo agregar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }

        public string Actualizar(ProductoEntidad obj)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_U", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_producto", SqlDbType.Int).Value = obj.id_producto;
                comando.Parameters.Add("@pid_categoria", SqlDbType.Int).Value = obj.id_categoria;
                comando.Parameters.Add("@pnombre_producto", SqlDbType.VarChar).Value = obj.nombre_producto;
                comando.Parameters.Add("@pdescripcion", SqlDbType.VarChar).Value = obj.descripcion;
                comando.Parameters.Add("@pprecio", SqlDbType.VarChar).Value = obj.precio;
                comando.Parameters.Add("@pestado", SqlDbType.VarChar).Value = obj.estado;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo actualizar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }


        public string Eliminar(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_D", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_producto", SqlDbType.Int).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo eliminar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }


        public string Activar(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_Activar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_producto", SqlDbType.VarChar).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo activar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }


        public string Desactivar(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Producto_Desactivar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_producto", SqlDbType.VarChar).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo desactivar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }
    }
}
