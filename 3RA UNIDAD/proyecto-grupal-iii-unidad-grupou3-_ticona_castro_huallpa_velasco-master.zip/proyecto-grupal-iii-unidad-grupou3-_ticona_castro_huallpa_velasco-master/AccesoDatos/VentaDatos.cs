﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace AccesoDatos
{
    public class VentaDatos
    {
        public DataTable Listar()
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            //Tabla.Columns[3].DataType = typeof(string);
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Venta_S", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                sqlcnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
        }
        public string Insertar(VentaEntidad obj)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Venta_I", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_pedido", SqlDbType.Int).Value = obj.id_pedido;
                comando.Parameters.Add("@pcategoria", SqlDbType.VarChar).Value = obj.categoria;
                comando.Parameters.Add("@pproducto", SqlDbType.VarChar).Value = obj.producto;
                comando.Parameters.Add("@pmesa", SqlDbType.VarChar).Value = obj.mesa;
                comando.Parameters.Add("@pcliente", SqlDbType.VarChar).Value = obj.cliente;
                comando.Parameters.Add("@pnrodocumento", SqlDbType.VarChar).Value = obj.nro_documento;
                comando.Parameters.Add("@ptelefono", SqlDbType.VarChar).Value = obj.telefono;
                comando.Parameters.Add("@pdireccion", SqlDbType.VarChar).Value = obj.direccion;
                comando.Parameters.Add("@pcantidad", SqlDbType.Int).Value = obj.cantidad;
                comando.Parameters.Add("@ppreciounitario", SqlDbType.VarChar).Value = obj.preciounitario;
                comando.Parameters.Add("@pestado", SqlDbType.VarChar).Value = obj.estado;
                comando.Parameters.Add("@pfecha", SqlDbType.VarChar).Value = obj.fecha;
                comando.Parameters.Add("@psubtotal", SqlDbType.VarChar).Value = obj.subtotal;
                comando.Parameters.Add("@pigv", SqlDbType.VarChar).Value = obj.igv;
                comando.Parameters.Add("@ptotal", SqlDbType.VarChar).Value = obj.total;
  
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo guardar";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }
        public string Existe(string valor)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Venta_Verificar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pvalor", SqlDbType.VarChar).Value = valor;
                SqlParameter parExiste = new SqlParameter();
                parExiste.ParameterName = ("@existe");
                parExiste.SqlDbType = SqlDbType.Int;
                parExiste.Direction = ParameterDirection.Output;
                comando.Parameters.Add(parExiste);
                sqlcnx.Open();
                comando.ExecuteNonQuery();
                Rpta = Convert.ToString(parExiste.Value);
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }
        public string Pagar(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Venta_Pagar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_pedido", SqlDbType.Int).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo activar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }

        public string Pendiente(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Venta_Pendiente", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_pedido", SqlDbType.Int).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo desactivar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }
        public DataTable Buscar(string busqueda)
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Venta_S_Buscar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pcliente", SqlDbType.VarChar).Value = busqueda;
                sqlcnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
        }
    }
    
}
