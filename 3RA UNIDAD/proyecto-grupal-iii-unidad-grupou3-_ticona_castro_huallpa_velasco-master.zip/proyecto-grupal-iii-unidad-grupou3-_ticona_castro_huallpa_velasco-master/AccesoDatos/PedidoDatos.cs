﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.Data;
using System.Data.SqlClient;

namespace AccesoDatos
{
    public class PedidoDatos
    {
        public DataTable ComboMesas()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection SqlCnx = new SqlConnection();

            try
            {
                //Establecer conexion
                SqlCnx = Conexion.getInstancia().EstablecerConexion();
                //Llamar al procedimiento almacenado
                SqlCommand comando = new SqlCommand("ListarMesa", SqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                SqlCnx.Open();
                Resultado = comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (SqlCnx.State == ConnectionState.Open) SqlCnx.Close();
            }

        }
        // Combo box productos
        public DataTable ComboCategorias()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection SqlCnx = new SqlConnection();

            try
            {
                //Establecer conexion
                SqlCnx = Conexion.getInstancia().EstablecerConexion();
                //Llamar al procedimiento almacenado
                SqlCommand comando = new SqlCommand("ListarCategoria", SqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                SqlCnx.Open();
                Resultado = comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (SqlCnx.State == ConnectionState.Open) SqlCnx.Close();
            }

        }
        public DataTable ComboProducto()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection SqlCnx = new SqlConnection();

            try
            {
                //Establecer conexion
                SqlCnx = Conexion.getInstancia().EstablecerConexion();
                //Llamar al procedimiento almacenado
                SqlCommand comando = new SqlCommand("ListarProducto", SqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                SqlCnx.Open();
                Resultado = comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (SqlCnx.State == ConnectionState.Open) SqlCnx.Close();
            }

        }
        public string Eliminar(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Pedido_D", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_pedido", SqlDbType.Int).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo eliminar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }

        public string Insertar(PedidoEntidad obj)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Pedido_I", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_categoria", SqlDbType.Int).Value = obj.id_categoria;
                comando.Parameters.Add("@pid_producto", SqlDbType.Int).Value = obj.id_producto;
                comando.Parameters.Add("@pid_mesa", SqlDbType.Int).Value = obj.id_mesa;
                comando.Parameters.Add("@pcliente", SqlDbType.VarChar).Value = obj.cliente;
                comando.Parameters.Add("@pnro_documento", SqlDbType.VarChar).Value = obj.nro_documento;
                comando.Parameters.Add("@ptelefono", SqlDbType.Char).Value = obj.telefono;
                comando.Parameters.Add("@pdireccion", SqlDbType.Text).Value = obj.direccion;
                comando.Parameters.Add("@pcantidad", SqlDbType.Int).Value = obj.cantidad;
                comando.Parameters.Add("@pestado", SqlDbType.VarChar).Value = obj.estado;
                comando.Parameters.Add("@pfecha", SqlDbType.VarChar).Value = obj.fecha;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo guardar";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }
        public DataTable Listar()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection SqlCnx = new SqlConnection();

            try
            {
                //Establecer conexion
                SqlCnx = Conexion.getInstancia().EstablecerConexion();
                //Llamar al procedimiento almacenado
                SqlCommand comando = new SqlCommand("USP_Pedido_S", SqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                SqlCnx.Open();
                Resultado = comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (SqlCnx.State == ConnectionState.Open) SqlCnx.Close();
            }

        }
        public string Existe(string valor)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Pedido_Verificar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pvalor", SqlDbType.VarChar).Value = valor;
                SqlParameter parExiste = new SqlParameter();
                parExiste.ParameterName = ("@existe");
                parExiste.SqlDbType = SqlDbType.Int;
                parExiste.Direction = ParameterDirection.Output;
                comando.Parameters.Add(parExiste);
                sqlcnx.Open();
                comando.ExecuteNonQuery();
                Rpta = Convert.ToString(parExiste.Value);
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }


        



        // BUSCAR VENTA
        public DataTable Buscar(string busqueda)//cliente y fecha
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Venta_S_Buscar", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pbusqueda", SqlDbType.VarChar).Value = busqueda;
                sqlcnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
        }


        public string Ocupado(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Mesa_Ocupado", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_mesa", SqlDbType.Int).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo activar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }


        public string Desocupado(int id)
        {
            string Rpta = "";
            SqlConnection sqlcnx = new SqlConnection();

            try
            {
                sqlcnx = Conexion.getInstancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Mesa_Desocupado", sqlcnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pid_mesa", SqlDbType.Int).Value = id;
                sqlcnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo desactivar el registro...";
            }
            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlcnx.State == ConnectionState.Open)
                {
                    sqlcnx.Close();
                }
            }
            return Rpta;
        }
    }
}
