CREATE PROCEDURE USP_TipoUsuario_I 
  @pdescripcion varchar(100)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.TipoUsuario
			VALUES(@pdescripcion)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE ACTUALIZAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_TipoUsuario_U
  @pid_tipo_usuario int,
  @pdescripcion varchar(100)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.TipoUsuario SET								 
			descripcion = @pdescripcion						
		WHERE id_tipo_usuario = @pid_tipo_usuario
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE ELIMINAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_TipoUsuario_D
  @pid_tipo_usuario int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			DELETE dbo.TipoUsuario 
			WHERE id_tipo_usuario = @pid_tipo_usuario
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE LISTAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_TipoUsuario_S
  
AS
BEGIN	
	SELECT * FROM TipoUsuario	
END
GO

-- PROCEDIMIENTO ALMACENADO DE BUSCAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_TipoUsuario_S_Buscar
  @pbusqueda varchar(150)
AS
BEGIN	
	SELECT id_tipo_usuario, descripcion  
	FROM dbo.TipoUsuario
	WHERE 
	descripcion LIKE '%' + @pbusqueda + '%'
END
GO

-- PROCEDIMIENTO ALMACENADO VERIFICAR
CREATE PROCEDURE USP_TipoUsuario_Verificar
  @pvalor varchar(100),
  @existe bit output  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY

		IF EXISTS (SELECT descripcion FROM TipoUsuario WHERE descripcion = LTRIM(rtrim(@pvalor)))
			BEGIN
				SET @existe=1
			END
		ELSE
		BEGIN
				SET @existe=0
			END		
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO