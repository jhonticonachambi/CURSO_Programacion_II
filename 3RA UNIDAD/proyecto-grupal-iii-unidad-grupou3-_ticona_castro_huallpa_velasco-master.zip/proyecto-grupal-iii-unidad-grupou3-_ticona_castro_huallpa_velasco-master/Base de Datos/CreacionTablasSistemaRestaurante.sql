create database db_restaurante
go

use db_restaurante
go

if(not exists(select 1 from sys.tables where name = 'TipoUsuario'))
create table dbo.TipoUsuario
(
	id_tipo_usuario int identity(1,1) primary key,
	descripcion varchar(100) not null
)
go

if(not exists(select 1 from sys.tables where name = 'Usuario'))
create table dbo.Usuario
(
	id_usuario int identity(1,1) primary key,
	id_tipo_usuario int,
	tipo_identificacion varchar(3) not null,
	nro_identificacion int unique not null,
	nombres varchar(100) not null,
	apellidos varchar(100) not null,
	contrase�a varchar(100) not null,
	email varchar(250) unique not null,
	celular char(9) unique not null,
	direccion text null,
	sexo char(1) not null,
	estado char(1) not null
	foreign key (id_tipo_usuario) references TipoUsuario
)
go

if(not exists(select 1 from sys.tables where name = 'Producto'))
create table dbo.Producto
(
	id_producto int identity(1,1) primary key,
	nombre_producto varchar(100) unique not null,
	descripcion varchar(250) not null,
	precio decimal not null
)
go

if(not exists(select 1 from sys.tables where name = 'Pedido'))
create table dbo.Pedido
(
	id_pedido int identity(1,1) primary key,
	id_producto int,
	cantidad int not null,
	descripcion varchar(250) not null,
	subtotal_precio decimal not null
	foreign key (id_producto) references Producto
)
go

if(not exists(select 1 from sys.tables where name = 'Boleta'))
create table dbo.Boleta
(
	id_boleta int identity(1,1) primary key,
	nombre_cliente varchar(200) not null,
	id_usuario int,
	fecha date not null,
	serie char(3) not null,
	correlativo char(6) not null,
	estado char(1) not null	
	foreign key (id_usuario) references Usuario
)
go

if(not exists(select 1 from sys.tables where name = 'DetalleBoleta'))
create table dbo.DetalleBoleta
(
	id_detalle_boleta int identity(1,1) primary key,
	id_boleta int,
	id_producto int,
	cantidad int not null,
	subtotal decimal(10,2) not null,
	igv decimal(5,2) not null,
	total decimal(10,2) not null,
	descuento decimal(5,2) null
	foreign key (id_boleta) references Boleta,
	foreign key (id_producto) references Producto
)
go

if(not exists(select 1 from sys.tables where name = 'Mesa'))
create table dbo.Mesa
(
	id_mesa int identity(1,1) primary key,
	numero int unique not null,
	estado varchar(250) not null,
)
go


if(not exists(select 1 from sys.tables where name = 'Venta'))
create table dbo.Venta
(
	id_venta int identity(1,1) primary key,
	id_producto int,
	id_categoria int,
	id_mesa int,
	cliente varchar(40) not null,
	nro_documento varchar(11) not null,
	telefono char(9) null,
	direccion text null,
	cantidad int not null,
	fecha date not null,
	subtotal decimal(10,2) not null,
	igv decimal(10,2) not null,
	total decimal(10,2) not null,
	estado varchar(50) not null,
	foreign key (id_mesa) references Mesa,
	foreign key (id_producto) references Producto,
	foreign key (id_categoria) references CategoriaProducto
)
go
