
/*Listar Venta*/
CREATE PROCEDURE USP_Venta_S
  
AS
BEGIN	
	
	SELECT v.id_venta,cp.nombre_categoria,p.nombre_producto,m.nombre,v.cliente,v.nro_documento,
	v.cantidad,v.fecha,v.total,v.estado
	FROM Venta as v 
	INNER JOIN CategoriaProducto as cp
	ON cp.id_categoria = v.id_categoria
	INNER JOIN Producto as p
	ON p.id_producto = v.id_producto
	INNER JOIN Mesa as m
	ON m.id_mesa = v.id_mesa
	WHERE v.estado='Pendiente'

END
GO

/*Agregar venta*/
CREATE PROCEDURE USP_Venta_I 

  @pid_producto int,
  @pid_categoria int,
  @pid_mesa int,
  @pcliente varchar(40),
  @pnro_documento varchar(11),
  @ptelefono char(9),
  @pdireccion text,
  @pcantidad int,
  @pfecha varchar(20),
  @psubtotal decimal(10,2),
  @pigv decimal(10,2),
  @ptotal decimal(10,2),
  @pestado varchar(50)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.Venta
			VALUES( @pid_producto,@pid_categoria,@pid_mesa,@pcliente,
	@pnro_documento,@ptelefono,@pdireccion,@pcantidad,@pfecha,
	@psubtotal,@pigv,@ptotal,@pestado)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

/*-----------Eliminar*/
CREATE PROCEDURE USP_Venta_D
  @pid_venta int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			DELETE dbo.Venta 
			WHERE id_venta = @pid_venta
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE BUSCAR 
CREATE PROCEDURE USP_Venta_S_Buscar
  @pcliente varchar(150),
  @pfecha varchar(50)
AS
BEGIN	
	SELECT v.id_venta,cp.nombre_categoria,p.nombre_producto,m.nombre,v.cliente,v.nro_documento,
	v.cantidad,v.fecha,v.total,v.estado
	FROM Venta as v 
	INNER JOIN CategoriaProducto as cp
	ON cp.id_categoria = v.id_categoria
	INNER JOIN Producto as p
	ON p.id_producto = v.id_producto
	INNER JOIN Mesa as m
	ON m.id_mesa = v.id_mesa

	WHERE (v.estado='Pendiente' AND (v.cliente LIKE '%' + @pcliente + '%' OR v.nro_documento LIKE '%' + @pcliente + '%')AND  (v.fecha LIKE '%'+ @pfecha  + '%')) 

END
GO

CREATE PROCEDURE USP_Venta_Pagar
  @pid_venta int
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Venta SET					 
			estado = 'Cancelado'
		WHERE id_venta= @pid_venta
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

CREATE PROCEDURE USP_Venta_Pendiente
  @pid_venta int
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Venta SET					 
			estado = 'Pendiente'
		WHERE id_venta= @pid_venta
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

CREATE PROCEDURE USP_Ventas_Verificar
  @pvalor varchar(100),
  @existe bit output  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY

		IF EXISTS (SELECT cliente FROM Venta WHERE cliente = LTRIM(rtrim(@pvalor)))
			BEGIN
				SET @existe=1
			END
		ELSE
		BEGIN
				SET @existe=0
			END		
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO


/*Agregar venta*/
CREATE PROCEDURE USP_Venta_I 

  @pid_producto int,
  @pid_categoria int,
  @pid_mesa int,
  @pcliente varchar(40),
  @pnro_documento varchar(11),
  @ptelefono char(9),
  @pdireccion text,
  @pcantidad int,
  @pfecha varchar(20),
  @psubtotal decimal(10,2),
  @pigv decimal(10,2),
  @ptotal decimal(10,2),
  @pestado varchar(50)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.Venta
			VALUES( @pid_producto,@pid_categoria,@pid_mesa,@pcliente,
	@pnro_documento,@ptelefono,@pdireccion,@pcantidad,@pfecha,
	@psubtotal,@pigv,@ptotal,@pestado)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

/*-------------------------------------------------------jhon-------------------------------*/
/*Agregar venta*/
CREATE PROC USP_Venta_Reingresar
  @pid_mesa int,
  @pcliente varchar(40),
  @pnro_documento varchar(11),
  @ptelefono char(9),
  @pdireccion text,
  @pcantidad int
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.Venta2
			VALUES(@pid_mesa,@pcliente,@pnro_documento,@ptelefono,
			@pdireccion,@pcantidad)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO


CREATE PROCEDURE USP_Venta2_Seleccionar
  
AS
BEGIN	
	
	SELECT v.id_ventas,m.numero,v.cliente,v.nro_documento,
	v.telefono,v.direccion,v.cantidad
	FROM Venta2 as v
	INNER JOIN Mesa as m
	ON m.id_mesa = v.id_mesa
	WHERE v.estado='Pendiente'

END
GO