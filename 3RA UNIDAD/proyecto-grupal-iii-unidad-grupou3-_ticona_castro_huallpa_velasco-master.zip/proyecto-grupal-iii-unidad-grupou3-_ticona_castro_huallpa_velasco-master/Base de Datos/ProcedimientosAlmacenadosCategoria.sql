-- PROCEDIMIENTO ALMACENADO DE INSERTAR EN LA TABLA CATEGORIA
CREATE PROCEDURE USP_Categoria_I 
  @pnombre varchar(100)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.CategoriaProducto
			VALUES(@pnombre)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE ACTUALIZAR EN LA TABLA CATEGORIA
CREATE PROCEDURE USP_Categoria_U
  @pid_categoria int,
  @pnombre varchar(100)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.CategoriaProducto SET								 
			nombre_categoria = @pnombre						
		WHERE id_categoria = @pid_categoria
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE ELIMINAR EN LA TABLA CATEGORIA
CREATE PROCEDURE USP_Categoria_D
  @pid_categoria int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			DELETE dbo.CategoriaProducto 
			WHERE id_categoria = @pid_categoria
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE LISTAR EN LA TABLA CATEGORIA
CREATE PROCEDURE USP_Categoria_S
  
AS
BEGIN	
	SELECT * FROM CategoriaProducto	
END
GO

-- PROCEDIMIENTO ALMACENADO DE BUSCAR EN LA TABLA CATEGORIA
CREATE PROCEDURE USP_Categoria_S_Buscar
  @pbusqueda varchar(150)
AS
BEGIN	
	SELECT id_categoria, nombre_categoria  
	FROM dbo.CategoriaProducto
	WHERE 
	nombre_categoria LIKE '%' + @pbusqueda + '%'
END
GO

-- PROCEDIMIENTO ALMACENADO VERIFICAR
CREATE PROCEDURE USP_Categoria_Verificar
  @pvalor varchar(100),
  @existe bit output  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY

		IF EXISTS (SELECT nombre_categoria FROM CategoriaProducto WHERE nombre_categoria = LTRIM(rtrim(@pvalor)))
			BEGIN
				SET @existe=1
			END
		ELSE
		BEGIN
				SET @existe=0
			END		
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO