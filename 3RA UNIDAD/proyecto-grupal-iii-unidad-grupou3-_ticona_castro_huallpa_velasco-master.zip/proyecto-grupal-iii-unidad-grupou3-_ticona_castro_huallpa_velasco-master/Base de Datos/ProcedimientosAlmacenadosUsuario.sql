-- Procedimientos Almacenados

-- PROCEDIMIENTO ALMACENADO DE INSERTAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_Usuario_I 
  @pid_tipo_usuario int,
  @ptipo_identificacion varchar(3),
  @pnro_identificacion int,  
  @pnombres varchar(100),
  @papellidos varchar(100),
  @pcontrase�a varchar(100),
  @pemail varchar(250),
  @pcelular char(9),
  @pdireccion text,
  @psexo char(1),
  @pestado char(1)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.Usuario
			VALUES(@pid_tipo_usuario, @ptipo_identificacion, @pnro_identificacion, @pnombres, @papellidos, @pcontrase�a, @pemail, @pcelular, @pdireccion, @psexo, @pestado)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE ACTUALIZAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_Usuario_U
  @pid_usuario int,
  @pid_tipo_usuario int,
  @ptipo_identificacion varchar(3),
  @pnro_identificacion int,  
  @pnombres varchar(100),
  @papellidos varchar(100),
  @pcontrase�a varchar(100),
  @pemail varchar(250),
  @pcelular char(9),
  @pdireccion text,
  @psexo char(1),
  @pestado char(1)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Usuario SET					
			id_tipo_usuario = @pid_tipo_usuario, 
			tipo_identificacion = @ptipo_identificacion,			
			nro_identificacion = @pnro_identificacion,
			nombres = @pnombres, 
			apellidos = @papellidos,			
			contrase�a = @pcontrase�a,
			email = @pemail, 
			celular = @pcelular,			
			direccion = @pdireccion,
			sexo = @psexo,
			estado = @pestado
		WHERE id_usuario = @pid_usuario
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO


-- PROCEDIMIENTO ALMACENADO DE ELIMINAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_Usuario_D
  @pid_usuario int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			DELETE dbo.Usuario 
			WHERE id_usuario = @pid_usuario
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE LISTAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_Usuario_S
  
AS
BEGIN	
	SELECT * FROM Usuario	
END
GO

-- PROCEDIMIENTO ALMACENADO DE BUSCAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_Usuario_S_Buscar
  @pbusqueda varchar(150)
AS
BEGIN	
	SELECT id_usuario, id_tipo_usuario, tipo_identificacion, nro_identificacion, nombres, apellidos, contrase�a, email, celular, direccion, sexo, estado  
	FROM dbo.Usuario
	WHERE 
	nro_identificacion LIKE '%' + @pbusqueda + '%'
	OR
	apellidos LIKE '%' + @pbusqueda + '%'
	OR
	email LIKE '%' + @pbusqueda + '%'
END
GO

-- PROCEDIMIENTO ALMACENADO DE ACTIVAR USUARIO
CREATE PROCEDURE USP_Usuario_Activar
  @pid_usuario int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Usuario SET					 
			estado = 'A'
		WHERE id_usuario = @pid_usuario
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE DESACTIVAR USUARIO
CREATE PROCEDURE USP_Usuario_Desactivar
  @pid_usuario int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Usuario SET					 
			estado = 'I'
		WHERE id_usuario = @pid_usuario
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO VERIFICAR
CREATE PROCEDURE USP_Usuario_Verificar
  @pvalor varchar(100),
  @existe bit output  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY

		IF EXISTS (SELECT nro_identificacion FROM Usuario WHERE nro_identificacion = LTRIM(rtrim(@pvalor)))
			BEGIN
				SET @existe=1
			END
		ELSE
		BEGIN
				SET @existe=0
			END		
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO LOGIN
CREATE PROCEDURE USP_Usuario_Logear
  @pusuario varchar(100),
  @pcontrase�a varchar(100)  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY

		SELECT u.nro_identificacion, u.email, u.celular, u.contrase�a, t.descripcion, u.estado, u.nombres, u.apellidos 
		FROM Usuario as u
		inner join TipoUsuario as t
		on u.id_tipo_usuario = t.id_tipo_usuario 
		WHERE (u.nro_identificacion = @pusuario or u.celular =  @pusuario) and u.contrase�a = @pcontrase�a
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO


