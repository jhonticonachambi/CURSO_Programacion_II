-- Procedimientos Almacenados

-- PROCEDIMIENTO ALMACENADO DE INSERTAR EN LA TABLA PRODUCTO
CREATE PROCEDURE USP_Producto_I 
  @pid_categoria int,
  @pnombre_producto varchar(100),
  @pdescripcion varchar(150),  
  @pprecio decimal(10,2),
  @pestado char(1)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.Producto
			VALUES(@pid_categoria, @pnombre_producto, @pdescripcion, @pprecio, @pestado)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE ACTUALIZAR EN LA TABLA PRODUCTO
CREATE PROCEDURE USP_Producto_U
  @pid_producto int,
  @pid_categoria int,
  @pnombre_producto varchar(100),
  @pdescripcion varchar(150),  
  @pprecio decimal(10,2),
  @pestado char(1)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Producto SET					
			id_categoria = @pid_categoria, 
			nombre_producto = @pnombre_producto,			
			descripcion = @pdescripcion,
			precio = @pprecio, 
			estado = @pestado
		WHERE id_producto = @pid_producto
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO


-- PROCEDIMIENTO ALMACENADO DE ELIMINAR EN LA TABLA PRODUCTO
CREATE PROCEDURE USP_Producto_D
  @pid_producto int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			DELETE dbo.Producto 
			WHERE id_producto = @pid_producto
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE LISTAR EN LA TABLA PRODUCTO
CREATE PROCEDURE USP_Producto_S
  
AS
BEGIN	
	SELECT p.id_producto, c.nombre_categoria, p.nombre_producto, p.descripcion, p.precio
		FROM Producto as p
		inner join CategoriaProducto as c
		on p.id_categoria = c.id_categoria 	
END
GO

-- PROCEDIMIENTO ALMACENADO DE BUSCAR EN LA TABLA PRODUCTO
CREATE PROCEDURE USP_Producto_S_Buscar
  @pbusqueda varchar(150)
AS
BEGIN	
	SELECT p.id_producto, c.nombre_categoria, p.nombre_producto, p.descripcion, p.precio
		FROM Producto as p
		inner join CategoriaProducto as c
		on p.id_categoria = c.id_categoria 	
		WHERE 
		nombre_categoria LIKE '%' + @pbusqueda + '%'
		OR
		nombre_producto LIKE '%' + @pbusqueda + '%'
END

-- PROCEDIMIENTO ALMACENADO DE ACTIVAR PRODUCTO
CREATE PROCEDURE USP_Producto_Activar
  @pid_producto int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Producto SET					 
			estado = 'A'
		WHERE id_producto = @pid_producto
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE DESACTIVAR PRODUCTO
CREATE PROCEDURE USP_Producto_Desactivar
  @pid_producto int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Producto SET					 
			estado = 'I'
		WHERE id_producto = @pid_producto
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO VERIFICAR
CREATE PROCEDURE USP_Producto_Verificar
  @pvalor varchar(100),
  @existe bit output  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY

		IF EXISTS (SELECT nombre_producto FROM Producto WHERE nombre_producto = LTRIM(rtrim(@pvalor)))
			BEGIN
				SET @existe=1
			END
		ELSE
		BEGIN
				SET @existe=0
			END		
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

CREATE PROCEDURE USP_Producto_PDF
  
AS
BEGIN	
	SELECT c.nombre_categoria, p.nombre_producto, p.precio, p.estado
		FROM Producto as p
		inner join CategoriaProducto as c
		on p.id_categoria = c.id_categoria 
		where p.estado = 'A'
		order by nombre_categoria desc
END
GO

