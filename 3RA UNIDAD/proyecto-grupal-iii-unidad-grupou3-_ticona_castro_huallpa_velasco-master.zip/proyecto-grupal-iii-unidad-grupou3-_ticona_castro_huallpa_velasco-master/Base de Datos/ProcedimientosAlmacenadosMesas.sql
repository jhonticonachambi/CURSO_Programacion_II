CREATE PROCEDURE USP_Mesa_I 
  @pnumero int,	
  @pestado varchar(250)
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
			INSERT INTO dbo.Mesa
			VALUES( @pnumero ,@pestado)
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO
/*Listar*/
CREATE PROCEDURE USP_Mesa_S
  
AS
BEGIN	
	SELECT * FROM dbo.Mesa	
END
GO

-- PROCEDIMIENTO ALMACENADO DE ACTIVAR USUARIO
CREATE PROCEDURE USP_Mesa_Ocupado
  @pid_mesa int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Mesa SET					 
			estado = 'O'
		WHERE id_mesa = @pid_mesa
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE ACTIVAR USUARIO
CREATE PROCEDURE USP_Mesa_Desocupado
  @pid_mesa int  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY
		UPDATE dbo.Mesa SET					 
			estado = 'D'
		WHERE id_mesa = @pid_mesa
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO

-- PROCEDIMIENTO ALMACENADO DE BUSCAR EN LA TABLA USUARIO
CREATE PROCEDURE USP_Mesa_S_Buscar
  @pbusqueda varchar(150)
AS
BEGIN	
	SELECT id_mesa, cantidad, estado
	FROM dbo.Mesa
	WHERE 
	id_mesa LIKE '%' + @pbusqueda + '%'
	OR
	cantidad LIKE '%' + @pbusqueda + '%'
	OR
	estado  LIKE '%' + @pbusqueda + '%'
END
GO
CREATE PROCEDURE USP_Mesa_Verificar
  @pvalor varchar(100),
  @existe bit output  
AS
BEGIN
	BEGIN TRAN
		BEGIN TRY

		IF EXISTS (SELECT id_mesa FROM Mesa WHERE id_mesa = LTRIM(rtrim(@pvalor)))
			BEGIN
				SET @existe=1
			END
		ELSE
		BEGIN
				SET @existe=0
			END		
	COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
	END
GO
