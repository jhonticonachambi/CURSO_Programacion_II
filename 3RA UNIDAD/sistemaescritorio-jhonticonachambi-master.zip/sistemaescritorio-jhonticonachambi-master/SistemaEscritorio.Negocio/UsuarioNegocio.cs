﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SisteemaEscritorio.Datos;
using SisteemaEscritorio.Entidad;
using System.Data;

namespace SistemaEscritorio.Negocio
{
    public class UsuarioNegocio
    {

        public static DataTable Listar()
        {
            UsuarioDatos obj = new UsuarioDatos();
            return obj.Listar();
        }

        public static DataTable Loguear(string Usuario,string Password)
        {
            UsuarioDatos objUsuario = new UsuarioDatos();
            return objUsuario.Loguear(Usuario,Password);
        }

    }
}
