﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SisteemaEscritorio.Datos;
using SisteemaEscritorio.Entidad;
using System.Data;

namespace SistemaEscritorio.Negocio
{
    public class PersonaNegocio
    {
        public static DataTable Listar()
        {
            PersonaDato obj = new PersonaDato();
            return obj.Listar();
        }

        public static DataTable Buscar(string busqueda)
        {
            PersonaDato obj = new PersonaDato();
            return obj.Buscar(busqueda);
        }

        public static string Insertar(string dni, string nombre, string apellido, string sexo, string email, string celular, string direccion, string fechanac)
        {
            PersonaDato obj = new PersonaDato();

            string existe = obj.Existe(dni);
            if (existe.Equals("1"))
            {
                return "La Persona ya existe en la BD...";
            }
            else
            {
                Persona objent = new Persona();
                objent.Dni = dni;
                objent.Nombre = nombre;
                objent.Apellido = apellido;
                //objent.Sexo = sexo;
                objent.Email = email;
                objent.Celular = celular;
                objent.Direccion = direccion;
                objent.FechaNac = fechanac;
                return obj.Insertar(objent);
            }
        }

        public static string Actualizar(int id, string dni, string nombre, string apellido, string sexo, string email, string celular, string direccion, string fechanac)
        {
            PersonaDato obj = new PersonaDato();

            string existe = obj.Existe(dni);
            if (existe.Equals("1"))
            {
                Persona objent = new Persona();
                objent.PersonaId = id;
                objent.Dni = dni;
                objent.Nombre = nombre;
                objent.Apellido = apellido;
                //objent.Sexo = sexo;
                objent.Email = email;
                objent.Celular = celular;
                objent.Direccion = direccion;
                objent.FechaNac = fechanac;
                return obj.Actualizar(objent);
            }
            else
            {
                
                return "La Persona no existe en la BD...";
            }
        }

        public static string Eliminar(int id)
        {
            PersonaDato obj = new PersonaDato();
            return obj.Eliminar(id);
        }
    }
}
