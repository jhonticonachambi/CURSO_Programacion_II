﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace SisteemaEscritorio.Datos
{
    class Conexion
    {
        private string BD;
        private string Server;
        private string User;
        private string Clave;
        private bool Autenticacion;
        private static Conexion cnx = null;

        private Conexion()
        {
            this.BD = "db_sistema";
            this.Server = "DESKTOP-67LRJGK"; 
            this.User = "sa";
            this.Clave = "machida001";
            this.Autenticacion = true; 

        }

        public SqlConnection EstablecerConexion()
        {
            SqlConnection cadena = new SqlConnection();

            try
            {
                cadena.ConnectionString = "Server=" + this.Server + ";" + "DataBase=" + this.BD + ";";
                if (this.Autenticacion) //seguridad windows true
                {
                    cadena.ConnectionString = cadena.ConnectionString + "Integrated Security = SSPI";
                }
                else //Seguridad sql
                {
                    cadena.ConnectionString = cadena.ConnectionString + "User Id" + this.User + ";" + "Password" + this.Clave;
                }
            }
            catch (Exception ex)
            {
                cadena = null;
                throw ex;
            }
            return cadena;
        }

        public static Conexion getIntancia()
        {
            if (cnx == null)
            {
                cnx = new Conexion();
            }
            return cnx;
        }

        internal static object getInstancia()
        {
            throw new NotImplementedException();
        }
    }
}
