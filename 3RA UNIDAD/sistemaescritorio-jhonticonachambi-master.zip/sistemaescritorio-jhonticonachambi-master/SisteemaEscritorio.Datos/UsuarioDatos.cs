﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SisteemaEscritorio.Entidad;

using System.Data;
using System.Data.SqlClient;
using SisteemaEscritorio.Datos;



namespace SisteemaEscritorio.Datos
{

    public class UsuarioDatos
    {
        public DataTable Listar()
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCnx = new SqlConnection();

            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Usuario_S", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                sqlCnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
        }

        public DataTable Loguear(string Usuario,string Password)
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCnx = new SqlConnection();

            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Usuario_Loguear", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pusuario", SqlDbType.VarChar).Value = Usuario;
                comando.Parameters.Add("@pclave", SqlDbType.VarChar).Value = Password;
                sqlCnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;

            }
            catch (Exception ex)
            {
                return null;
                throw ex;
            }
            finally
            {   
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
        }



    }
}
