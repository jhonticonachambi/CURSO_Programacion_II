﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SisteemaEscritorio.Entidad;







namespace SisteemaEscritorio.Datos
{
    public class PersonaDato
    {
        //Metodo Listar
        public DataTable Listar()
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCnx = new SqlConnection();

            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Persona_S", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                sqlCnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;

            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
        }

        public DataTable Buscar(string Busqueda)
        {
            SqlDataReader resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCnx = new SqlConnection();

            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Persona_S_Buscar", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pbusqueda", SqlDbType.VarChar).Value = Busqueda;
                sqlCnx.Open();
                resultado = comando.ExecuteReader();
                Tabla.Load(resultado);
                return Tabla;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
        }

        public string Existe(string Valor)
        {
            string Rpta = "";
            SqlConnection sqlCnx = new SqlConnection();
            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Persona_Verificar", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pvalor", SqlDbType.VarChar).Value = Valor;
                SqlParameter ParExiste = new SqlParameter();
                ParExiste.ParameterName = "@existe";
                ParExiste.SqlDbType = SqlDbType.Int;
                ParExiste.Direction = ParameterDirection.Output;
                comando.Parameters.Add(ParExiste);
                sqlCnx.Open();
                comando.ExecuteNonQuery();
                Rpta = Convert.ToString(ParExiste.Value);
            }

            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
            return Rpta;
        }

        public string Insertar(Persona obj)
        {
            string Rpta = "";
            SqlConnection sqlCnx = new SqlConnection();

            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Persona_I", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@pdni", SqlDbType.VarChar).Value = obj.Dni;
                comando.Parameters.Add("@pnombre", SqlDbType.VarChar).Value = obj.Nombre;
                comando.Parameters.Add("@papellido", SqlDbType.VarChar).Value = obj.Apellido;
                //comando.Parameters.Add("@psexo", SqlDbType.VarChar).Value = obj.Sexo;
                comando.Parameters.Add("@pemail", SqlDbType.VarChar).Value = obj.Email;
                comando.Parameters.Add("@pcelular", SqlDbType.VarChar).Value = obj.Celular;
                comando.Parameters.Add("@pdireccion", SqlDbType.Text).Value = obj.Direccion;
                comando.Parameters.Add("@pfechanacimiento", SqlDbType.VarChar).Value = obj.FechaNac;
                sqlCnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo agregar el registro...";
            }

            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
            return Rpta;
        }

        public string Actualizar(Persona obj)
        {
            string Rpta = "";
            SqlConnection sqlCnx = new SqlConnection();

            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Persona_U", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@ppersona_id", SqlDbType.VarChar).Value = obj.PersonaId;
                comando.Parameters.Add("@pdni", SqlDbType.VarChar).Value = obj.Dni;
                comando.Parameters.Add("@pnombre", SqlDbType.VarChar).Value = obj.Nombre;
                comando.Parameters.Add("@papellido", SqlDbType.VarChar).Value = obj.Apellido;
                //comando.Parameters.Add("@psexo", SqlDbType.VarChar).Value = obj.Sexo;
                comando.Parameters.Add("@pemail", SqlDbType.VarChar).Value = obj.Email;
                comando.Parameters.Add("@pcelular", SqlDbType.VarChar).Value = obj.Celular;
                comando.Parameters.Add("@pdireccion", SqlDbType.Text).Value = obj.Direccion;
                comando.Parameters.Add("@pfechanacimiento", SqlDbType.VarChar).Value = obj.FechaNac;
                sqlCnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo actualizar el registro...";
            }

            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
            return Rpta;
        }




        public string Eliminar(int id)
        {
            string Rpta = "";
            SqlConnection sqlCnx = new SqlConnection();

            try
            {
                sqlCnx = Conexion.getIntancia().EstablecerConexion();
                SqlCommand comando = new SqlCommand("USP_Persona_D", sqlCnx);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.Add("@ppersona_id", SqlDbType.VarChar).Value = id;
                sqlCnx.Open();
                Rpta = comando.ExecuteNonQuery() == 1 ? "OK" : "No se pudo eliminar el registro...";
            }

            catch (Exception ex)
            {
                Rpta = ex.Message;
            }
            finally
            {
                if (sqlCnx.State == ConnectionState.Open) sqlCnx.Close();
            }
            return Rpta;
        }


    }
}
