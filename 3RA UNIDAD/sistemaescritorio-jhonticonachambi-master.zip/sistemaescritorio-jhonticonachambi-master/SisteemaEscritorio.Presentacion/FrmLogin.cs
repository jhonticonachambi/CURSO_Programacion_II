﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaEscritorio.Negocio;

namespace SisteemaEscritorio.Presentacion
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try{
                string Usuario, Password;
                Usuario = txtUsuario.Text.Trim();
                Password = txtContraseña.Text.Trim();

                DataTable Tabla = new DataTable();
                Tabla = UsuarioNegocio.Loguear(Usuario, Password);


                if (Tabla.Rows.Count <= 0)
                {
                    MessageBox.Show("El usuario np esta registrado en la base de datos ", "Autenticacion", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {
                    if (Convert.ToString(Tabla.Rows[0][5]) == "I")
                    {
                        MessageBox.Show("El Usuario se encuentra Inavilitado ", "consulte con eladministrador ", MessageBoxButtons.OK, MessageBoxIcon.Error);


                    }
                    else
                    {
                        MDIPrincipal MDI = new MDIPrincipal();
                        MDI.IdUsuario = Convert.ToInt32(Tabla.Rows[0][0]);   //idusuario
                        MDI.Apellido = Convert.ToString(Tabla.Rows[0][1]);   //apelldio
                        MDI.Nombre = Convert.ToString(Tabla.Rows[0][2]);     //nombre
                        MDI.Usuario = Convert.ToString(Tabla.Rows[0][3]);   //usuario
                        MDI.Nivel = Convert.ToString(Tabla.Rows[0][4]);     //nivel
                        MDI.Estado = Convert.ToString(Tabla.Rows[0][5]);    //estado
                        MDI.Show();
                        this.Hide();
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
