﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SisteemaEscritorio.Presentacion
{
    public partial class MDIPrincipal : Form
    {
        private int childFormNumber = 0;


        public int IdUsuario;
        public string Apellido;
        public string Nombre;
        public string Usuario;
        public string Nivel;
        public string Estado;

        public MDIPrincipal()
        {
            InitializeComponent();
        }
        
        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Ventana " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }


        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFrmCategorias(); // Abrir Formulario FrmCategoria
        }


        void AbrirFrmCategorias()
        {
            FrmCategoria frm = new FrmCategoria();
            frm.MdiParent = this;
            frm.Show();
            
        }
        void Abrirformulario()
        {
            Reportes.FrmReporteCategoria frma = new Reportes.FrmReporteCategoria();
            frma.MdiParent = this;
            frma.Show();

        }

        void Abrirformulario2()
        {
            Reportes.FrmParametro frma = new Reportes.FrmParametro();
            frma.MdiParent = this;
            frma.Show();

        }
        void Salir()
        {
            DialogResult Opcion;
            Opcion = MessageBox.Show("Esta seguro de salir ","Sistema",MessageBoxButtons.OKCancel,MessageBoxIcon.Question);
            if(Opcion == DialogResult.OK)
            {
                Application.Exit();
            }
        }




        private void MDIPrincipal_Load(object sender, EventArgs e)
        {
            stBarraEstado.Text = "Bienvenido " + Nombre + " , " + Apellido + " Nivel : [" + Nivel + "]";

            if (this.Nivel.Equals("Administrador"))
            {
                MenuMantenimiento.Visible = true;
                MenuConsultas.Visible = true;
                MenuConsultas.Visible = true;
                MenuAyuda.Visible = true;
                MenuSalir.Visible = true;
            }
            else
            {
                if (this.Nivel.Equals("Supervisor"))
                {

                    MenuManCategoria.Enabled = false;
                    MenuManDocumento.Visible = true;
                    MenuManPersona.Enabled = false;
                    MenuManUsuario.Enabled = false;

                    btnCategoria.Enabled = false;
                    btnDocumentos.Enabled = false;
                    btnPersona.Enabled = false;


                }
                else
                {
                    MenuMantenimiento.Enabled = false;
                    MenuReportes.Enabled = false;

                    btnCategoria.Enabled = false;
                    btnDocumentos.Enabled = false;
                    btnPersona.Enabled = false;

                }

            }

        }

        private void documentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCategoria Frm1 = new FrmCategoria();
            Frm1.MdiParent = this;
            Frm1.Show();
        }


        private void personaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPersona Frm1 = new FrmPersona();
            Frm1.MdiParent = this;
            Frm1.Show();
        }

        private void MDIPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void menuStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void parametroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Abrirformulario2();
        }

        private void usuarioiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Abrirformulario();
        }

        private void stBarraEstado_Click(object sender, EventArgs e)
        {

        }

        private void MenuSalir_Click(object sender, EventArgs e)
        {
            this.Salir();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Salir();
        }

        private void MenuManUsuario_Click(object sender, EventArgs e)
        {
            FrmUsuario Frm1 = new FrmUsuario();
            Frm1.MdiParent = this;
            Frm1.Show();
        }
    }
}
