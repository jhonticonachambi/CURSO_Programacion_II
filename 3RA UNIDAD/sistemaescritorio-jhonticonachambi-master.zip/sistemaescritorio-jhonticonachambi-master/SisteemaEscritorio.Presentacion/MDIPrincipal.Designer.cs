﻿namespace SisteemaEscritorio.Presentacion
{
    partial class MDIPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDIPrincipal));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.MenuMantenimiento = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuManCategoria = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuManDocumento = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuManPersona = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuManUsuario = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuConsultas = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuReportes = new System.Windows.Forms.ToolStripMenuItem();
            this.parametroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuarioiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAyuda = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.stBarraEstado = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.btnCategoria = new System.Windows.Forms.ToolStripButton();
            this.btnDocumentos = new System.Windows.Forms.ToolStripButton();
            this.btnPersona = new System.Windows.Forms.ToolStripButton();
            this.btnUsuario = new System.Windows.Forms.ToolStripButton();
            this.btnConsulta = new System.Windows.Forms.ToolStripButton();
            this.btnReportes = new System.Windows.Forms.ToolStripButton();
            this.btnSalir = new System.Windows.Forms.ToolStripButton();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuMantenimiento,
            this.MenuConsultas,
            this.MenuReportes,
            this.MenuAyuda,
            this.MenuSalir});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(884, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            this.menuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip_ItemClicked);
            // 
            // MenuMantenimiento
            // 
            this.MenuMantenimiento.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuManCategoria,
            this.MenuManDocumento,
            this.MenuManPersona,
            this.MenuManUsuario});
            this.MenuMantenimiento.Name = "MenuMantenimiento";
            this.MenuMantenimiento.Size = new System.Drawing.Size(101, 20);
            this.MenuMantenimiento.Text = "Mantenimiento";
            // 
            // MenuManCategoria
            // 
            this.MenuManCategoria.Name = "MenuManCategoria";
            this.MenuManCategoria.Size = new System.Drawing.Size(180, 22);
            this.MenuManCategoria.Text = "Categoria";
            this.MenuManCategoria.Click += new System.EventHandler(this.categoriaToolStripMenuItem_Click);
            // 
            // MenuManDocumento
            // 
            this.MenuManDocumento.Name = "MenuManDocumento";
            this.MenuManDocumento.Size = new System.Drawing.Size(180, 22);
            this.MenuManDocumento.Text = "Documento";
            this.MenuManDocumento.Click += new System.EventHandler(this.documentoToolStripMenuItem_Click);
            // 
            // MenuManPersona
            // 
            this.MenuManPersona.Name = "MenuManPersona";
            this.MenuManPersona.Size = new System.Drawing.Size(180, 22);
            this.MenuManPersona.Text = "Persona";
            this.MenuManPersona.Click += new System.EventHandler(this.personaToolStripMenuItem_Click);
            // 
            // MenuManUsuario
            // 
            this.MenuManUsuario.Name = "MenuManUsuario";
            this.MenuManUsuario.Size = new System.Drawing.Size(180, 22);
            this.MenuManUsuario.Text = "Usuario";
            this.MenuManUsuario.Click += new System.EventHandler(this.MenuManUsuario_Click);
            // 
            // MenuConsultas
            // 
            this.MenuConsultas.Name = "MenuConsultas";
            this.MenuConsultas.Size = new System.Drawing.Size(71, 20);
            this.MenuConsultas.Text = "Consultas";
            // 
            // MenuReportes
            // 
            this.MenuReportes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parametroToolStripMenuItem,
            this.usuarioiToolStripMenuItem});
            this.MenuReportes.Name = "MenuReportes";
            this.MenuReportes.Size = new System.Drawing.Size(65, 20);
            this.MenuReportes.Text = "Reportes";
            // 
            // parametroToolStripMenuItem
            // 
            this.parametroToolStripMenuItem.Name = "parametroToolStripMenuItem";
            this.parametroToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.parametroToolStripMenuItem.Text = "Parametro";
            this.parametroToolStripMenuItem.Click += new System.EventHandler(this.parametroToolStripMenuItem_Click);
            // 
            // usuarioiToolStripMenuItem
            // 
            this.usuarioiToolStripMenuItem.Name = "usuarioiToolStripMenuItem";
            this.usuarioiToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.usuarioiToolStripMenuItem.Text = "Categoria";
            this.usuarioiToolStripMenuItem.Click += new System.EventHandler(this.usuarioiToolStripMenuItem_Click);
            // 
            // MenuAyuda
            // 
            this.MenuAyuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.MenuAyuda.Name = "MenuAyuda";
            this.MenuAyuda.Size = new System.Drawing.Size(53, 20);
            this.MenuAyuda.Text = "Ay&uda";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(184, 26);
            this.contentsToolStripMenuItem.Text = "&Contenido";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(181, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(184, 26);
            this.aboutToolStripMenuItem.Text = "&Acerca de... ...";
            // 
            // MenuSalir
            // 
            this.MenuSalir.Name = "MenuSalir";
            this.MenuSalir.Size = new System.Drawing.Size(41, 20);
            this.MenuSalir.Text = "Salir";
            this.MenuSalir.Click += new System.EventHandler(this.MenuSalir_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnCategoria,
            this.btnDocumentos,
            this.toolStripSeparator2,
            this.btnPersona,
            this.btnUsuario,
            this.btnConsulta,
            this.btnReportes,
            this.toolStripSeparator1,
            this.btnSalir});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(884, 27);
            this.toolStrip.TabIndex = 1;
            this.toolStrip.Text = "ToolStrip";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stBarraEstado});
            this.statusStrip.Location = new System.Drawing.Point(0, 491);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(884, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // stBarraEstado
            // 
            this.stBarraEstado.Name = "stBarraEstado";
            this.stBarraEstado.Size = new System.Drawing.Size(42, 17);
            this.stBarraEstado.Text = "Estado";
            this.stBarraEstado.Click += new System.EventHandler(this.stBarraEstado_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 560);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "label1";
            // 
            // btnCategoria
            // 
            this.btnCategoria.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCategoria.Image = global::SisteemaEscritorio.Presentacion.Properties.Resources.application;
            this.btnCategoria.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCategoria.Name = "btnCategoria";
            this.btnCategoria.Size = new System.Drawing.Size(24, 24);
            this.btnCategoria.Text = "Categoria";
            // 
            // btnDocumentos
            // 
            this.btnDocumentos.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnDocumentos.Image = global::SisteemaEscritorio.Presentacion.Properties.Resources.application_edit;
            this.btnDocumentos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDocumentos.Name = "btnDocumentos";
            this.btnDocumentos.Size = new System.Drawing.Size(24, 24);
            this.btnDocumentos.Text = "toolStripButton2";
            // 
            // btnPersona
            // 
            this.btnPersona.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPersona.Image = global::SisteemaEscritorio.Presentacion.Properties.Resources.community_users;
            this.btnPersona.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPersona.Name = "btnPersona";
            this.btnPersona.Size = new System.Drawing.Size(24, 24);
            this.btnPersona.Text = "toolStripButton2";
            // 
            // btnUsuario
            // 
            this.btnUsuario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnUsuario.Image = global::SisteemaEscritorio.Presentacion.Properties.Resources.user_accept;
            this.btnUsuario.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnUsuario.Name = "btnUsuario";
            this.btnUsuario.Size = new System.Drawing.Size(24, 24);
            this.btnUsuario.Text = "toolStripButton2";
            // 
            // btnConsulta
            // 
            this.btnConsulta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnConsulta.Image = global::SisteemaEscritorio.Presentacion.Properties.Resources.computer_accept;
            this.btnConsulta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnConsulta.Name = "btnConsulta";
            this.btnConsulta.Size = new System.Drawing.Size(24, 24);
            this.btnConsulta.Text = "toolStripButton2";
            // 
            // btnReportes
            // 
            this.btnReportes.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnReportes.Image = global::SisteemaEscritorio.Presentacion.Properties.Resources.chart;
            this.btnReportes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(24, 24);
            this.btnReportes.Text = "toolStripButton2";
            // 
            // btnSalir
            // 
            this.btnSalir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalir.Image = global::SisteemaEscritorio.Presentacion.Properties.Resources.cancelar_p;
            this.btnSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(24, 24);
            this.btnSalir.Text = "toolStripButton2";
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
            this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(184, 26);
            this.indexToolStripMenuItem.Text = "&Índice";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("searchToolStripMenuItem.Image")));
            this.searchToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(184, 26);
            this.searchToolStripMenuItem.Text = "&Buscar";
            // 
            // MDIPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 513);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDIPrincipal";
            this.Text = "MDIPrincipal";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MDIPrincipal_FormClosing);
            this.Load += new System.EventHandler(this.MDIPrincipal_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripStatusLabel stBarraEstado;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuMantenimiento;
        private System.Windows.Forms.ToolStripMenuItem MenuAyuda;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem MenuManCategoria;
        private System.Windows.Forms.ToolStripMenuItem MenuManDocumento;
        private System.Windows.Forms.ToolStripMenuItem MenuManPersona;
        private System.Windows.Forms.ToolStripMenuItem MenuManUsuario;
        private System.Windows.Forms.ToolStripMenuItem MenuConsultas;
        private System.Windows.Forms.ToolStripMenuItem MenuReportes;
        private System.Windows.Forms.ToolStripButton btnCategoria;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem MenuSalir;
        private System.Windows.Forms.ToolStripButton btnDocumentos;
        private System.Windows.Forms.ToolStripButton btnPersona;
        private System.Windows.Forms.ToolStripButton btnUsuario;
        private System.Windows.Forms.ToolStripButton btnConsulta;
        private System.Windows.Forms.ToolStripButton btnReportes;
        private System.Windows.Forms.ToolStripButton btnSalir;
        private System.Windows.Forms.ToolStripMenuItem parametroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuarioiToolStripMenuItem;
    }
}



