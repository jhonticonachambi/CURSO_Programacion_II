﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisteemaEscritorio.Presentacion.Reportes
{
    public partial class FrmParametro : Form
    {
        public FrmParametro()
        {
            InitializeComponent();
        }

        private void FrmParametro_Load(object sender, EventArgs e)
        {
            string busqueda;
            busqueda = txtBusqueda.Text;
            // TODO: esta línea de código carga datos en la tabla 'DsSistema.USP_Usuario_S_Buscar' Puede moverla o quitarla según sea necesario.
            this.USP_Usuario_S_BuscarTableAdapter.Fill(this.DsSistema.USP_Usuario_S_Buscar,busqueda);

            this.reportViewer1.RefreshReport();
           // this.reportViewer2.RefreshReport();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
