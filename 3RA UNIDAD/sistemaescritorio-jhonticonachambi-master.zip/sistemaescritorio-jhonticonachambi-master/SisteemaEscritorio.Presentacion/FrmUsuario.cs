﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Web.UI.WebControls;
using SistemaEscritorio.Negocio;

namespace SisteemaEscritorio.Presentacion
{
    public partial class FrmUsuario : Form
    {
        public FrmUsuario()
        {
            InitializeComponent();
        }
        private void TitulosGrilla()
        {
            dgvListar.Columns[0].Visible = false; //Columna Seleccionar
            dgvListar.Columns[1].HeaderText = "ID-Usuario";
            dgvListar.Columns[2].HeaderText = "ID-Persona";
            dgvListar.Columns[3].HeaderText = "Usuario";
            dgvListar.Columns[4].HeaderText = "Clave";
            dgvListar.Columns[5].HeaderText = "Nivel";
            dgvListar.Columns[6].HeaderText = "Estado";
            dgvListar.Columns[1].Width = 70;
            dgvListar.Columns[2].Width = 80;
            dgvListar.Columns[3].Width = 80;
            dgvListar.Columns[4].Width = 80;
            dgvListar.Columns[5].Width = 80;
            dgvListar.Columns[6].Width = 80;
        }
        private void ListarGrilla()
        {
            try
            {
                dgvListar.DataSource = UsuarioNegocio.Listar();
                this.TitulosGrilla();
                lblTotal.Text = "Total de registro: " + Convert.ToString(dgvListar.Rows.Count);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }


        private void FrmUsuario_Load(object sender, EventArgs e)
        {
            this.ListarGrilla();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dgvListar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvListar_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
