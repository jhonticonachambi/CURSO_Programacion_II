﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using SistemaEscritorio.Negocio;

namespace SisteemaEscritorio.Presentacion
{
    public partial class FrmPersona : Form
    {
        public FrmPersona()
        {
            InitializeComponent();
        }
        private void TitulosGrilla()
        {
            dgvListar.Columns[0].Visible = false; //Columna Seleccionar
            dgvListar.Columns[1].HeaderText = "Código";
            dgvListar.Columns[2].HeaderText = "Dni";
            dgvListar.Columns[3].HeaderText = "Nombres";
            dgvListar.Columns[4].HeaderText = "Apellidos";
            dgvListar.Columns[5].HeaderText = "Sexo";
            dgvListar.Columns[6].HeaderText = "Email";
            dgvListar.Columns[7].HeaderText = "Celular";
            dgvListar.Columns[8].HeaderText = "Direccion";
            dgvListar.Columns[9].HeaderText = "Fecha Nacimiento";
            dgvListar.Columns[1].Width = 50;
            dgvListar.Columns[2].Width = 80;
            dgvListar.Columns[3].Width = 100;
            dgvListar.Columns[4].Width = 100;
            dgvListar.Columns[5].Width = 80;
            dgvListar.Columns[6].Width = 150;
            dgvListar.Columns[7].Width = 80;
            dgvListar.Columns[8].Width = 150;
            dgvListar.Columns[9].Width = 100;
        }
        private void Cargarcomboestado()
        {
            cmbSexo.Items.Clear();
            cmbSexo.Items.Add(new ListItem("Masculino", "M"));
            cmbSexo.Items.Add(new ListItem("Femenino", "F"));
        }
        private void ListarGrilla()
        {
            try
            {
                dgvListar.DataSource = PersonaNegocio.Listar();
                this.TitulosGrilla();
                lblTotal.Text = "Total de registro: " + Convert.ToString(dgvListar.Rows.Count);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }


        private void Buscar()
        {
            try
            {
                string buscar;
                buscar = txtBuscar.Text;
                dgvListar.DataSource = PersonaNegocio.Buscar(buscar);
                this.TitulosGrilla();
                lblTotal.Text = "Total de registro: " + Convert.ToString(dgvListar.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void Limpiar()
        {
            txtApellido.Clear();
            txtCelular.Clear();
            txtDireccion.Clear();
            txtDni.Clear();
            txtEmail.Clear();
            txtFecha.Clear();
            txtNombre.Clear();
            
        }
        private void Visualizar()
        {
            btnGrabar.Visible = true;
            btnActualizar.Visible = true;

            dgvListar.Columns[0].Visible = false;
            btnEliminar.Visible = false;
        }
        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema Escritorio", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void MensajeCorrecto(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema Escritorio", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }





        private void FrmPersona_Load(object sender, EventArgs e)
        {
            //tabGestionar.SelectedIndex = 0;
            //this.StyleManager = metroStyleManager1;
            this.ListarGrilla();
            this.Cargarcomboestado();
            int valor;
            valor = Convert.ToInt32(dgvListar.Rows[dgvListar.RowCount - 1].Cells[1].Value);
            txtid.Text = (valor + 1).ToString();

            dgvListar.Columns[0].Visible = false;
            btnEliminar.Visible = false;    
        }

        private void dgvListar_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                this.Limpiar();
                this.Visualizar();
                btnActualizar.Visible = true;
                btnGrabar.Visible = false;
                txtid.Text = Convert.ToString(dgvListar.CurrentRow.Cells["persona_id"].Value);
                txtDni.Text = Convert.ToString(dgvListar.CurrentRow.Cells["dni"].Value);
                txtNombre.Text = Convert.ToString(dgvListar.CurrentRow.Cells["nombre"].Value);
                txtApellido.Text = Convert.ToString(dgvListar.CurrentRow.Cells["apellido"].Value);
                cmbSexo.Text = Convert.ToString(dgvListar.CurrentRow.Cells["sexo"].Value);
                txtEmail.Text = Convert.ToString(dgvListar.CurrentRow.Cells["email"].Value);
                txtCelular.Text = Convert.ToString(dgvListar.CurrentRow.Cells["celular"].Value);
                txtDireccion.Text = Convert.ToString(dgvListar.CurrentRow.Cells["direccion"].Value);
                txtFecha.Text = Convert.ToString(dgvListar.CurrentRow.Cells["fechanacimiento"].Value);

                if (dgvListar.CurrentRow.Cells["sexo"].Value.Equals("M"))
                {
                    cmbSexo.Text = "Masculino";
                }
                if (dgvListar.CurrentRow.Cells["sexo"].Value.Equals("F"))
                {
                    cmbSexo.Text = "Femenino";
                }
                tabGestionar.SelectedIndex = 1;
            }
            catch (Exception)
            {
                MessageBox.Show("Seleccione desde la celda Dni");
            }
        }

        private void dgvListar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
